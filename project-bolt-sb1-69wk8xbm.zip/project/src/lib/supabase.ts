import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type Listing = {
  id: string;
  user_id: string;
  product_name: string | null;
  title: string | null;
  alternative_titles: string[];
  description: string | null;
  short_description: string | null;
  recommended_price: number | null;
  price_range_min: number | null;
  price_range_max: number | null;
  category: string | null;
  keywords: string[];
  suggested_condition: string | null;
  buyer_qa: { question: string; answer: string }[];
  negotiation_price: number | null;
  minimum_price: number | null;
  platform_formats: Record<string, string>;
  input_brand: string | null;
  input_model: string | null;
  input_condition: string | null;
  input_location: string | null;
  input_language: string | null;
  input_description: string | null;
  image_urls: string[];
  status: string;
  created_at: string;
  updated_at: string;
};

export type Credits = {
  id: string;
  user_id: string;
  free_credits: number;
  paid_credits: number;
  plan: string;
};

export type Subscription = {
  id: string;
  user_id: string;
  plan: string;
  status: string;
  current_period_start: string | null;
  current_period_end: string | null;
};
