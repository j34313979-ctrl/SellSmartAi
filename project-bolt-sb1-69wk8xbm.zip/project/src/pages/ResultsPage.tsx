import { useState, useEffect } from 'react';
import {
  Sparkles, TrendingUp, Tag, FileText, MessageSquare, AlertCircle,
  ArrowRight, Save, Loader2, Info,
} from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Listing } from '@/lib/supabase';
import { navigate } from '@/lib/router';
import { CopyButton } from '@/components/CopyButton';

const PLATFORMS = ['facebook', 'kijiji', 'ebay', 'craigslist', 'vinted'] as const;
type Platform = (typeof PLATFORMS)[number];

const platformLabels: Record<Platform, string> = {
  facebook: 'Facebook Marketplace',
  kijiji: 'Kijiji',
  ebay: 'eBay',
  craigslist: 'Craigslist',
  vinted: 'Vinted',
};

export function ResultsPage({ listingId }: { listingId: string }) {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [listing, setListing] = useState<Listing | null>(null);
  const [loading, setLoading] = useState(true);
  const [activePlatform, setActivePlatform] = useState<Platform>('facebook');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('listings')
      .select('*')
      .eq('id', listingId)
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data, error }) => {
        if (data) setListing(data as Listing);
        setLoading(false);
      });
  }, [listingId, user]);

  if (!user) {
    navigate('/signin');
    return null;
  }

  if (loading) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 text-teal-500 animate-spin" />
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gray-50 px-4">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">{t.common.error}</p>
          <button
            onClick={() => navigate('/dashboard')}
            className="mt-4 text-sm text-teal-600 font-medium"
          >
            {t.results.backToDashboard}
          </button>
        </div>
      </div>
    );
  }

  const formatPrice = (price: number | null) => {
    if (price === null || price === undefined) return '—';
    return `$${price.toFixed(2)}`;
  };

  const handleSave = async () => {
    await supabase.from('listings').update({ status: 'published' }).eq('id', listing.id);
    setSaved(true);
  };

  const buyerQuestions = [
    { key: 'available', q: t.results.questions.available },
    { key: 'lowest', q: t.results.questions.lowest },
    { key: 'deliver', q: t.results.questions.deliver },
    { key: 'damage', q: t.results.questions.damage },
    { key: 'why', q: t.results.questions.why },
  ];

  const buyerQa = listing.buyer_qa || [];
  const platformFormat = listing.platform_formats?.[activePlatform] || '';

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">{t.results.title}</h1>
            <p className="text-sm text-gray-500">
              {listing.product_name || listing.title || 'Listing'}
            </p>
          </div>
        </div>

        {/* Images */}
        {listing.image_urls && listing.image_urls.length > 0 && (
          <div className="mb-6 flex gap-2 overflow-x-auto pb-2">
            {listing.image_urls.map((url, i) => (
              <img
                key={i}
                src={url}
                alt=""
                className="w-24 h-24 rounded-lg object-cover flex-shrink-0 border border-gray-200"
              />
            ))}
          </div>
        )}

        {/* Product identification */}
        <Section icon={Tag} title={t.results.product} subtitle={t.results.productDescription}>
          <p className="text-base font-medium text-gray-900">{listing.product_name || '—'}</p>
          {listing.suggested_condition && (
            <p className="mt-2 text-sm text-gray-500">
              {t.create.condition}: {listing.suggested_condition}
            </p>
          )}
          {listing.product_name && listing.product_name.toLowerCase().includes('verify') && (
            <div className="mt-3 flex items-start gap-2 p-3 rounded-lg bg-amber-50 text-amber-700 text-sm">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              {t.results.verifyNote}
            </div>
          )}
        </Section>

        {/* Price */}
        <Section icon={TrendingUp} title={t.results.recommendedPrice}>
          <div className="flex flex-wrap items-baseline gap-6">
            <div>
              <p className="text-xs text-gray-400 mb-1">{t.results.suggestedPrice}</p>
              <p className="text-3xl font-bold text-teal-600">
                {formatPrice(listing.recommended_price)}
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-400 mb-1">{t.results.priceRange}</p>
              <p className="text-xl font-semibold text-gray-700">
                {formatPrice(listing.price_range_min)} – {formatPrice(listing.price_range_max)}
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-400 mb-1">{t.results.negotiationPrice}</p>
              <p className="text-lg font-medium text-gray-600">
                {formatPrice(listing.negotiation_price)}
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-400 mb-1">{t.results.minimumPrice}</p>
              <p className="text-lg font-medium text-gray-600">
                {formatPrice(listing.minimum_price)}
              </p>
            </div>
          </div>
          <div className="mt-4 flex items-start gap-2 p-3 rounded-lg bg-gray-50 text-gray-500 text-xs">
            <Info className="w-4 h-4 flex-shrink-0 mt-0.5" />
            {t.results.priceDisclaimer}
          </div>
        </Section>

        {/* Optimized title */}
        <Section icon={Tag} title={t.results.optimizedTitle}>
          <div className="flex items-start justify-between gap-3">
            <p className="text-base font-semibold text-gray-900 flex-1">{listing.title}</p>
            <CopyButton text={listing.title || ''} />
          </div>
        </Section>

        {/* Alternative titles */}
        {listing.alternative_titles && listing.alternative_titles.length > 0 && (
          <Section icon={Tag} title={t.results.alternativeTitles}>
            <div className="space-y-2">
              {listing.alternative_titles.map((title, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between gap-3 p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors"
                >
                  <p className="text-sm text-gray-700 flex-1">{title}</p>
                  <CopyButton text={title} />
                </div>
              ))}
            </div>
          </Section>
        )}

        {/* Description */}
        <Section icon={FileText} title={t.results.description}>
          <div className="flex items-start justify-between gap-3 mb-2">
            <p className="text-xs text-gray-400">{t.results.shortDescription}</p>
            <CopyButton text={listing.short_description || ''} />
          </div>
          <div className="p-4 rounded-lg bg-gray-50 text-sm text-gray-600 mb-4 whitespace-pre-wrap">
            {listing.short_description}
          </div>
          <div className="flex items-start justify-between gap-3 mb-2">
            <p className="text-xs text-gray-400">{t.results.description}</p>
            <CopyButton text={listing.description || ''} />
          </div>
          <div className="p-4 rounded-lg bg-white border border-gray-100 text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">
            {listing.description}
          </div>
        </Section>

        {/* Keywords */}
        {listing.keywords && listing.keywords.length > 0 && (
          <Section icon={Tag} title={t.results.keywords}>
            <div className="flex flex-wrap gap-2">
              {listing.keywords.map((kw, i) => (
                <span
                  key={i}
                  className="px-3 py-1.5 text-sm rounded-full bg-teal-50 text-teal-700 border border-teal-100"
                >
                  {kw}
                </span>
              ))}
            </div>
          </Section>
        )}

        {/* Buyer replies */}
        {buyerQa.length > 0 && (
          <Section icon={MessageSquare} title={t.results.buyerReplies}>
            <div className="space-y-3">
              {buyerQuestions.map((q, i) => {
                const qa = buyerQa[i];
                if (!qa) return null;
                return (
                  <div key={q.key} className="p-4 rounded-lg border border-gray-100">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div>
                        <p className="text-xs text-gray-400 mb-1">{q.q}</p>
                        <p className="text-sm font-medium text-gray-700">{qa.question || q.q}</p>
                      </div>
                      <CopyButton text={qa.answer || ''} />
                    </div>
                    <p className="text-sm text-gray-600 mt-2 p-3 rounded-lg bg-gray-50">
                      {qa.answer}
                    </p>
                  </div>
                );
              })}
            </div>
          </Section>
        )}

        {/* Platform formats */}
        <Section icon={FileText} title={t.results.platformFormats}>
          <div className="flex gap-1 border-b border-gray-200 mb-4 overflow-x-auto">
            {PLATFORMS.map((p) => (
              <button
                key={p}
                onClick={() => setActivePlatform(p)}
                className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                  activePlatform === p
                    ? 'border-teal-500 text-teal-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                {platformLabels[p]}
              </button>
            ))}
          </div>
          <div className="flex items-start justify-between gap-3 mb-2">
            <span className="text-xs text-gray-400">{platformLabels[activePlatform]}</span>
            <CopyButton text={platformFormat} />
          </div>
          <div className="p-4 rounded-lg bg-white border border-gray-100 text-sm text-gray-700 whitespace-pre-wrap leading-relaxed min-h-[100px]">
            {platformFormat || '—'}
          </div>
        </Section>

        {/* Actions */}
        <div className="mt-8 flex flex-col sm:flex-row gap-3">
          {saved ? (
            <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-teal-50 text-teal-700 text-sm font-medium">
              <Save className="w-4 h-4" />
              {t.results.saved}
            </div>
          ) : (
            <button
              onClick={handleSave}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-white border border-gray-200 text-gray-700 font-semibold text-sm hover:bg-gray-50 transition-all"
            >
              <Save className="w-4 h-4" />
              {t.results.saveListing}
            </button>
          )}
          <button
            onClick={() => navigate('/create')}
            className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-600 text-white font-semibold text-sm hover:from-teal-600 hover:to-cyan-700 transition-all shadow-md"
          >
            {t.results.createNew}
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => navigate('/dashboard')}
            className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-gray-500 font-medium text-sm hover:bg-gray-100 transition-all"
          >
            {t.results.backToDashboard}
          </button>
        </div>
      </div>
    </div>
  );
}

function Section({
  icon: Icon,
  title,
  subtitle,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="mb-4 bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 rounded-lg bg-teal-50 flex items-center justify-center">
          <Icon className="w-4 h-4 text-teal-600" />
        </div>
        <div>
          <h2 className="font-semibold text-gray-900 text-sm">{title}</h2>
          {subtitle && <p className="text-xs text-gray-400">{subtitle}</p>}
        </div>
      </div>
      {children}
    </div>
  );
}
