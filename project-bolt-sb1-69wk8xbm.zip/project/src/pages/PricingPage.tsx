import { useLanguage } from '@/context/LanguageContext';
import { PricingSection } from '@/components/PricingSection';

export function PricingPage() {
  const { t } = useLanguage();

  return (
    <div>
      <div className="bg-gradient-to-b from-teal-50/30 to-white py-12 text-center">
        <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 px-4">{t.landing.pricingTitle}</h1>
        <p className="mt-3 text-lg text-gray-600 px-4">{t.landing.pricingSubtitle}</p>
      </div>
      <PricingSection />
    </div>
  );
}
