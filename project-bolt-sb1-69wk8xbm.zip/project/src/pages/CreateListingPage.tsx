import { useState, useRef, type ChangeEvent, type DragEvent } from 'react';
import {
  Upload, X, Camera, ArrowRight, ArrowLeft, Sparkles, AlertCircle, Loader2,
} from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { navigate } from '@/lib/router';
import type { Listing } from '@/lib/supabase';

type Step = 1 | 2 | 3;

const MAX_PHOTOS = 5;

export function CreateListingPage() {
  const { t, lang } = useLanguage();
  const { user, credits, refreshCredits } = useAuth();
  const [step, setStep] = useState<Step>(1);
  const [photos, setPhotos] = useState<string[]>([]);
  const [photoFiles, setPhotoFiles] = useState<File[]>([]);
  const [whatSelling, setWhatSelling] = useState('');
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [condition, setCondition] = useState('');
  const [location, setLocation] = useState('');
  const [listingLang, setListingLang] = useState<'en' | 'fr'>(lang);
  const [error, setError] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const totalCredits = (credits?.free_credits ?? 0) + (credits?.paid_credits ?? 0);

  const handlePhotoSelect = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const remaining = MAX_PHOTOS - photos.length;
    const selected = Array.from(files).slice(0, remaining);

    setUploading(true);
    const newPreviews: string[] = [];
    const newFiles: File[] = [];

    for (const file of selected) {
      const preview = URL.createObjectURL(file);
      newPreviews.push(preview);
      newFiles.push(file);
    }

    setPhotos((prev) => [...prev, ...newPreviews]);
    setPhotoFiles((prev) => [...prev, ...newFiles]);
    setUploading(false);
  };

  const handleDrop = (e: DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    handlePhotoSelect(e.dataTransfer.files);
  };

  const removePhoto = (index: number) => {
    URL.revokeObjectURL(photos[index]);
    setPhotos((prev) => prev.filter((_, i) => i !== index));
    setPhotoFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleFileInput = (e: ChangeEvent<HTMLInputElement>) => {
    handlePhotoSelect(e.target.files);
    e.target.value = '';
  };

  const handleNext = () => {
    if (step === 1 && photos.length === 0) {
      setError(t.create.needPhotos);
      return;
    }
    setError(null);
    setStep((prev) => (prev + 1) as Step);
  };

  const handleBack = () => {
    setError(null);
    setStep((prev) => (prev - 1) as Step);
  };

  const handleGenerate = async () => {
    if (photos.length === 0) {
      setError(t.create.needPhotos);
      return;
    }
    if (!condition) {
      setError(t.create.needCondition);
      return;
    }
    if (totalCredits <= 0) {
      navigate('/pricing');
      return;
    }

    setGenerating(true);
    setError(null);

    try {
      // Upload photos to Supabase storage
      const imageUrls: string[] = [];
      for (let i = 0; i < photoFiles.length; i++) {
        const file = photoFiles[i];
        const ext = file.name.split('.').pop() || 'jpg';
        const fileName = `${user!.id}/${Date.now()}-${i}.${ext}`;

        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('listing-photos')
          .upload(fileName, file);

        if (uploadError) {
          throw new Error('Failed to upload photos');
        }

        const { data: urlData } = supabase.storage
          .from('listing-photos')
          .getPublicUrl(uploadData.path);
        imageUrls.push(urlData.publicUrl);
      }

      // Call the AI generation edge function
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-listing`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            images: imageUrls,
            brand,
            model,
            condition,
            location,
            language: listingLang,
            description: whatSelling,
          }),
        }
      );

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || 'AI generation failed');
      }

      const result = await response.json();

      // Save listing to database
      const { data: listing, error: dbError } = await supabase
        .from('listings')
        .insert({
          product_name: result.product_name,
          title: result.title,
          alternative_titles: result.alternative_titles || [],
          description: result.description,
          short_description: result.short_description,
          recommended_price: result.recommended_price,
          price_range_min: result.price_range_min,
          price_range_max: result.price_range_max,
          category: result.category,
          keywords: result.keywords || [],
          suggested_condition: result.suggested_condition,
          buyer_qa: result.buyer_qa || [],
          negotiation_price: result.negotiation_price,
          minimum_price: result.minimum_price,
          platform_formats: result.platform_formats || {},
          input_brand: brand,
          input_model: model,
          input_condition: condition,
          input_location: location,
          input_language: listingLang,
          input_description: whatSelling,
          image_urls: imageUrls,
          status: 'draft',
        })
        .select()
        .single();

      if (dbError) throw new Error('Failed to save listing');

      // Decrement credits
      if (credits && credits.free_credits > 0) {
        await supabase
          .from('credits')
          .update({ free_credits: credits.free_credits - 1 })
          .eq('user_id', user!.id);
      } else if (credits && credits.paid_credits > 0) {
        await supabase
          .from('credits')
          .update({ paid_credits: credits.paid_credits - 1 })
          .eq('user_id', user!.id);
      }

      await refreshCredits();
      navigate(`/results/${listing.id}`);
    } catch (err) {
      const message = err instanceof Error ? err.message : t.common.error;
      setError(message);
    } finally {
      setGenerating(false);
    }
  };

  if (!user) {
    navigate('/signin');
    return null;
  }

  if (totalCredits <= 0 && step === 1) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-12 bg-gray-50">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 rounded-2xl bg-teal-50 flex items-center justify-center mx-auto mb-4">
            <Sparkles className="w-8 h-8 text-teal-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">{t.create.creditsWarning}</h2>
          <button
            onClick={() => navigate('/pricing')}
            className="mt-4 inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-600 text-white font-semibold text-sm hover:from-teal-600 hover:to-cyan-700 transition-all shadow-md"
          >
            {t.create.upgradeLink}
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">{t.create.title}</h1>
          <div className="mt-4 flex items-center gap-2">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center gap-2">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold transition-colors ${
                    step >= s
                      ? 'bg-teal-500 text-white'
                      : 'bg-gray-200 text-gray-400'
                  }`}
                >
                  {s}
                </div>
                {s < 3 && (
                  <div
                    className={`w-12 h-0.5 rounded-full transition-colors ${
                      step > s ? 'bg-teal-500' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="mt-2 flex gap-8 text-xs text-gray-500">
            <span className={step >= 1 ? 'text-teal-600 font-medium' : ''}>{t.create.step1}</span>
            <span className={step >= 2 ? 'text-teal-600 font-medium' : ''}>{t.create.step2}</span>
            <span className={step >= 3 ? 'text-teal-600 font-medium' : ''}>{t.create.step3}</span>
          </div>
        </div>

        {error && (
          <div className="mb-4 flex items-center gap-2 p-3 rounded-lg bg-red-50 text-red-700 text-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            {error}
          </div>
        )}

        {/* Step 1: Upload */}
        {step === 1 && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-1">{t.create.uploadTitle}</h2>
            <p className="text-sm text-gray-500 mb-4">{t.create.uploadSubtitle}</p>

            {/* Drop zone */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${
                dragOver
                  ? 'border-teal-500 bg-teal-50/50'
                  : 'border-gray-200 hover:border-teal-300 hover:bg-gray-50'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                multiple
                onChange={handleFileInput}
                className="hidden"
              />
              <div className="w-14 h-14 rounded-2xl bg-teal-50 flex items-center justify-center mx-auto mb-3">
                <Upload className="w-7 h-7 text-teal-600" />
              </div>
              <p className="text-sm font-medium text-gray-700">{t.create.uploadButton}</p>
              <p className="text-xs text-gray-400 mt-1">
                {photos.length}/{MAX_PHOTOS}
              </p>
            </div>

            {/* Previews */}
            {photos.length > 0 && (
              <div className="mt-4 grid grid-cols-3 sm:grid-cols-5 gap-3">
                {photos.map((photo, i) => (
                  <div key={i} className="relative group aspect-square rounded-lg overflow-hidden bg-gray-100">
                    <img src={photo} alt="" className="w-full h-full object-cover" />
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        removePhoto(i);
                      }}
                      className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/60 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
                {photos.length < MAX_PHOTOS && (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="aspect-square rounded-lg border-2 border-dashed border-gray-200 hover:border-teal-300 flex items-center justify-center text-gray-400 hover:text-teal-500 transition-colors"
                  >
                    <Camera className="w-6 h-6" />
                  </button>
                )}
              </div>
            )}

            {uploading && (
              <div className="mt-4 flex items-center justify-center gap-2 text-sm text-gray-500">
                <Loader2 className="w-4 h-4 animate-spin" />
                {t.common.loading}
              </div>
            )}

            <div className="mt-6 flex justify-end">
              <button
                onClick={handleNext}
                disabled={photos.length === 0}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-600 text-white font-semibold text-sm hover:from-teal-600 hover:to-cyan-700 transition-all shadow-md disabled:opacity-50"
              >
                {t.create.next}
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Details */}
        {step === 2 && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                {t.create.whatSelling}
              </label>
              <input
                type="text"
                value={whatSelling}
                onChange={(e) => setWhatSelling(e.target.value)}
                placeholder={t.create.whatSellingPlaceholder}
                className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  {t.create.brand}
                </label>
                <input
                  type="text"
                  value={brand}
                  onChange={(e) => setBrand(e.target.value)}
                  placeholder={t.create.brandPlaceholder}
                  className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  {t.create.model}
                </label>
                <input
                  type="text"
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  placeholder={t.create.modelPlaceholder}
                  className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t.create.condition}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {(['new', 'like_new', 'good', 'fair', 'poor'] as const).map((c) => (
                  <button
                    key={c}
                    onClick={() => setCondition(c)}
                    className={`px-3 py-2.5 rounded-lg text-sm font-medium border transition-all ${
                      condition === c
                        ? 'border-teal-500 bg-teal-50 text-teal-700'
                        : 'border-gray-200 text-gray-600 hover:border-gray-300'
                    }`}
                  >
                    {t.create.conditions[c]}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  {t.create.location}
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder={t.create.locationPlaceholder}
                  className="w-full px-4 py-2.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t.create.language}
                </label>
                <div className="flex gap-2">
                  <button
                    onClick={() => setListingLang('en')}
                    className={`flex-1 px-3 py-2.5 rounded-lg text-sm font-medium border transition-all ${
                      listingLang === 'en'
                        ? 'border-teal-500 bg-teal-50 text-teal-700'
                        : 'border-gray-200 text-gray-600 hover:border-gray-300'
                    }`}
                  >
                    English
                  </button>
                  <button
                    onClick={() => setListingLang('fr')}
                    className={`flex-1 px-3 py-2.5 rounded-lg text-sm font-medium border transition-all ${
                      listingLang === 'fr'
                        ? 'border-teal-500 bg-teal-50 text-teal-700'
                        : 'border-gray-200 text-gray-600 hover:border-gray-300'
                    }`}
                  >
                    Français
                  </button>
                </div>
              </div>
            </div>

            <div className="flex justify-between pt-2">
              <button
                onClick={handleBack}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-gray-600 font-medium text-sm hover:bg-gray-100 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                {t.create.back}
              </button>
              <button
                onClick={handleNext}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-600 text-white font-semibold text-sm hover:from-teal-600 hover:to-cyan-700 transition-all shadow-md"
              >
                {t.create.next}
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Generate */}
        {step === 3 && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            {generating ? (
              <div className="py-16 text-center">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center mx-auto mb-4 animate-pulse">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-lg font-semibold text-gray-900 mb-2">{t.create.generating}</h2>
                <div className="mt-4 flex justify-center gap-1.5">
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      className="w-2 h-2 rounded-full bg-teal-500 animate-bounce"
                      style={{ animationDelay: `${i * 150}ms` }}
                    />
                  ))}
                </div>
              </div>
            ) : (
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-4">{t.create.step3}</h2>

                {/* Summary */}
                <div className="space-y-3 mb-6">
                  <div className="flex gap-3">
                    <div className="flex -space-x-2">
                      {photos.slice(0, 3).map((p, i) => (
                        <img
                          key={i}
                          src={p}
                          alt=""
                          className="w-12 h-12 rounded-lg border-2 border-white object-cover shadow-sm"
                        />
                      ))}
                    </div>
                    <div className="text-sm text-gray-500">
                      {photos.length} photo{photos.length > 1 ? 's' : ''}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    {whatSelling && (
                      <div className="p-3 rounded-lg bg-gray-50">
                        <span className="text-gray-400">{t.create.whatSelling.split('(')[0]}: </span>
                        <span className="text-gray-700 font-medium">{whatSelling}</span>
                      </div>
                    )}
                    {brand && (
                      <div className="p-3 rounded-lg bg-gray-50">
                        <span className="text-gray-400">{t.create.brand.split('(')[0]}: </span>
                        <span className="text-gray-700 font-medium">{brand}</span>
                      </div>
                    )}
                    {model && (
                      <div className="p-3 rounded-lg bg-gray-50">
                        <span className="text-gray-400">{t.create.model.split('(')[0]}: </span>
                        <span className="text-gray-700 font-medium">{model}</span>
                      </div>
                    )}
                    {condition && (
                      <div className="p-3 rounded-lg bg-gray-50">
                        <span className="text-gray-400">{t.create.condition}: </span>
                        <span className="text-gray-700 font-medium">
                          {t.create.conditions[condition as keyof typeof t.create.conditions]}
                        </span>
                      </div>
                    )}
                    {location && (
                      <div className="p-3 rounded-lg bg-gray-50">
                        <span className="text-gray-400">{t.create.location}: </span>
                        <span className="text-gray-700 font-medium">{location}</span>
                      </div>
                    )}
                    <div className="p-3 rounded-lg bg-gray-50">
                      <span className="text-gray-400">{t.create.language}: </span>
                      <span className="text-gray-700 font-medium">
                        {listingLang === 'en' ? 'English' : 'Français'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex justify-between pt-2">
                  <button
                    onClick={handleBack}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-gray-600 font-medium text-sm hover:bg-gray-100 transition-colors"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    {t.create.back}
                  </button>
                  <button
                    onClick={handleGenerate}
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-600 text-white font-semibold text-sm hover:from-teal-600 hover:to-cyan-700 transition-all shadow-lg shadow-teal-500/20"
                  >
                    <Sparkles className="w-4 h-4" />
                    {t.create.generateButton}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
