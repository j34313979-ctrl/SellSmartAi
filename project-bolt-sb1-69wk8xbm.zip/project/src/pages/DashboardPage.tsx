import { useState, useEffect } from 'react';
import {
  Sparkles, Trash2, Eye, RefreshCw, Loader2, Package, Calendar, Tag,
} from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Listing } from '@/lib/supabase';
import { navigate } from '@/lib/router';

export function DashboardPage() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [regeneratingId, setRegeneratingId] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('listings')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .then(({ data, error }) => {
        if (data) setListings(data as Listing[]);
        setLoading(false);
      });
  }, [user]);

  if (!user) {
    navigate('/signin');
    return null;
  }

  const handleDelete = async (id: string) => {
    if (!confirm(t.dashboard.deleteConfirm)) return;
    await supabase.from('listings').delete().eq('id', id);
    setListings((prev) => prev.filter((l) => l.id !== id));
  };

  const handleRegenerate = async (listing: Listing) => {
    setRegeneratingId(listing.id);
    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-listing`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            images: listing.image_urls,
            brand: listing.input_brand,
            model: listing.input_model,
            condition: listing.input_condition,
            location: listing.input_location,
            language: listing.input_language,
            description: listing.input_description,
          }),
        }
      );

      if (!response.ok) throw new Error('Regeneration failed');
      const result = await response.json();

      await supabase
        .from('listings')
        .update({
          product_name: result.product_name,
          title: result.title,
          alternative_titles: result.alternative_titles || [],
          description: result.description,
          short_description: result.short_description,
          recommended_price: result.recommended_price,
          price_range_min: result.price_range_min,
          price_range_max: result.price_range_max,
          category: result.category,
          keywords: result.keywords || [],
          suggested_condition: result.suggested_condition,
          buyer_qa: result.buyer_qa || [],
          negotiation_price: result.negotiation_price,
          minimum_price: result.minimum_price,
          platform_formats: result.platform_formats || {},
        })
        .eq('id', listing.id);

      navigate(`/results/${listing.id}`);
    } catch {
      setRegeneratingId(null);
    }
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString(
      undefined,
      { year: 'numeric', month: 'short', day: 'numeric' }
    );
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">{t.dashboard.title}</h1>
          <p className="mt-1 text-sm text-gray-500">{t.dashboard.subtitle}</p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-teal-500 animate-spin" />
          </div>
        ) : listings.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <Package className="w-8 h-8 text-gray-300" />
            </div>
            <p className="text-gray-500 mb-4">{t.dashboard.empty}</p>
            <button
              onClick={() => navigate('/create')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-600 text-white font-semibold text-sm hover:from-teal-600 hover:to-cyan-700 transition-all shadow-md"
            >
              <Sparkles className="w-4 h-4" />
              {t.dashboard.emptyCta}
            </button>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {listings.map((listing) => (
              <div
                key={listing.id}
                className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden hover:shadow-md transition-shadow"
              >
                {/* Image or placeholder */}
                {listing.image_urls && listing.image_urls.length > 0 ? (
                  <div className="aspect-video bg-gray-100 overflow-hidden">
                    <img
                      src={listing.image_urls[0]}
                      alt=""
                      className="w-full h-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="aspect-video bg-gray-100 flex items-center justify-center">
                    <Package className="w-10 h-10 text-gray-300" />
                  </div>
                )}

                <div className="p-4">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="font-semibold text-sm text-gray-900 line-clamp-2 flex-1">
                      {listing.title || listing.product_name || 'Untitled'}
                    </h3>
                    {listing.recommended_price != null && (
                      <span className="text-sm font-bold text-teal-600 flex-shrink-0">
                        ${listing.recommended_price.toFixed(0)}
                      </span>
                    )}
                  </div>

                  {listing.product_name && (
                    <p className="text-xs text-gray-400 mb-2 flex items-center gap-1">
                      <Tag className="w-3 h-3" />
                      {listing.product_name}
                    </p>
                  )}

                  <div className="flex items-center gap-3 text-xs text-gray-400 mb-3">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {formatDate(listing.created_at)}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                      listing.status === 'published'
                        ? 'bg-teal-50 text-teal-600'
                        : 'bg-gray-100 text-gray-500'
                    }`}>
                      {t.dashboard.statuses[listing.status as keyof typeof t.dashboard.statuses] || listing.status}
                    </span>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => navigate(`/results/${listing.id}`)}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-gray-100 text-gray-700 text-xs font-medium hover:bg-gray-200 transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      {t.dashboard.reopen}
                    </button>
                    <button
                      onClick={() => handleRegenerate(listing)}
                      disabled={regeneratingId === listing.id}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-teal-50 text-teal-700 text-xs font-medium hover:bg-teal-100 transition-colors disabled:opacity-50"
                    >
                      {regeneratingId === listing.id ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <RefreshCw className="w-3.5 h-3.5" />
                      )}
                      {t.dashboard.regenerate}
                    </button>
                    <button
                      onClick={() => handleDelete(listing.id)}
                      className="inline-flex items-center justify-center px-3 py-2 rounded-lg bg-gray-100 text-gray-400 hover:bg-red-50 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
