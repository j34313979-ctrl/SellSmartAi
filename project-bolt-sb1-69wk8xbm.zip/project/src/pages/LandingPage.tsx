import {
  Sparkles, Camera, Edit3, Wand2, Tag, FileText, Languages,
  MessageSquare, TrendingUp, ChevronDown, ArrowRight, Check,
} from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { useAuth } from '@/context/AuthContext';
import { navigate } from '@/lib/router';
import { PricingSection } from '@/components/PricingSection';

export function LandingPage() {
  const { t } = useLanguage();
  const { user } = useAuth();

  const features = [
    { icon: TrendingUp, title: t.landing.feature1Title, desc: t.landing.feature1Desc },
    { icon: Tag, title: t.landing.feature2Title, desc: t.landing.feature2Desc },
    { icon: FileText, title: t.landing.feature3Title, desc: t.landing.feature3Desc },
    { icon: MessageSquare, title: t.landing.feature4Title, desc: t.landing.feature4Desc },
    { icon: Sparkles, title: t.landing.feature5Title, desc: t.landing.feature5Desc },
    { icon: Languages, title: t.landing.feature6Title, desc: t.landing.feature6Desc },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-teal-50/50 via-white to-white">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-teal-100/40 via-transparent to-transparent" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24 sm:pt-28 sm:pb-32">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-teal-50 border border-teal-200 mb-6">
              <Sparkles className="w-4 h-4 text-teal-600" />
              <span className="text-sm font-medium text-teal-700">AI-Powered Listing Creator</span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight tracking-tight">
              {t.hero.headline}
            </h1>
            <p className="mt-6 text-lg sm:text-xl text-gray-600 leading-relaxed">
              {t.hero.subtitle}
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
              <button
                onClick={() => navigate(user ? '/create' : '/signup')}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-600 text-white font-semibold text-base hover:from-teal-600 hover:to-cyan-700 transition-all shadow-lg shadow-teal-500/20 hover:shadow-xl hover:shadow-teal-500/30"
              >
                {t.hero.cta}
                <ArrowRight className="w-5 h-5" />
              </button>
              <button
                onClick={() => {
                  document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white text-gray-700 font-semibold text-base border border-gray-200 hover:bg-gray-50 transition-all"
              >
                {t.hero.secondaryCta}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Before/After */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">{t.landing.beforeAfterTitle}</h2>
            <p className="mt-3 text-lg text-gray-600">{t.landing.beforeAfterSubtitle}</p>
          </div>
          <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {/* Before */}
            <div className="rounded-2xl border-2 border-dashed border-gray-200 p-8 bg-gray-50">
              <div className="flex items-center gap-2 mb-4">
                <Camera className="w-5 h-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-500">{t.landing.beforeLabel}</span>
              </div>
              <div className="aspect-square rounded-xl bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center mb-4">
                <Camera className="w-16 h-16 text-gray-400" />
              </div>
              <p className="text-sm text-gray-400 italic">
                {t.create.whatSellingPlaceholder}
              </p>
            </div>
            {/* After */}
            <div className="rounded-2xl border-2 border-teal-200 p-8 bg-teal-50/30 shadow-lg shadow-teal-500/5">
              <div className="flex items-center gap-2 mb-4">
                <Check className="w-5 h-5 text-teal-600" />
                <span className="text-sm font-medium text-teal-700">{t.landing.afterLabel}</span>
              </div>
              <div className="rounded-xl bg-white p-4 shadow-sm border border-teal-100">
                <p className="font-semibold text-gray-900 text-sm mb-2">
                  Levi's Trucker Sherpa Jacket — Like New, Size M
                </p>
                <p className="text-2xl font-bold text-teal-600 mb-1">$65</p>
                <p className="text-xs text-gray-500 mb-3">Expected range: $55–$80</p>
                <div className="flex flex-wrap gap-1">
                  {['leather jacket', 'vintage', 'size M', 'like new'].map((kw) => (
                    <span key={kw} className="px-2 py-0.5 text-xs rounded-full bg-teal-100 text-teal-700">
                      {kw}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">{t.landing.howItWorksTitle}</h2>
            <p className="mt-3 text-lg text-gray-600">{t.landing.howItWorksSubtitle}</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              { icon: Camera, step: '1', title: t.landing.step1Title, desc: t.landing.step1Desc },
              { icon: Edit3, step: '2', title: t.landing.step2Title, desc: t.landing.step2Desc },
              { icon: Wand2, step: '3', title: t.landing.step3Title, desc: t.landing.step3Desc },
            ].map((s) => (
              <div key={s.step} className="text-center">
                <div className="relative inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white shadow-md mb-4">
                  <s.icon className="w-7 h-7 text-teal-600" />
                  <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-teal-500 text-white text-xs font-bold flex items-center justify-center">
                    {s.step}
                  </span>
                </div>
                <h3 className="font-semibold text-lg text-gray-900 mb-2">{s.title}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">{t.landing.featuresTitle}</h2>
            <p className="mt-3 text-lg text-gray-600">{t.landing.featuresSubtitle}</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <div
                key={i}
                className="p-6 rounded-2xl border border-gray-100 hover:border-teal-200 hover:shadow-lg transition-all bg-white"
              >
                <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center mb-4">
                  <f.icon className="w-6 h-6 text-teal-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{f.title}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <PricingSection />

      {/* FAQ */}
      <FAQSection />

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-teal-500 to-cyan-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white">{t.landing.ctaTitle}</h2>
          <p className="mt-4 text-lg text-teal-50">{t.landing.ctaSubtitle}</p>
          <button
            onClick={() => navigate(user ? '/create' : '/signup')}
            className="mt-8 inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-white text-teal-700 font-semibold text-base hover:bg-teal-50 transition-all shadow-lg"
          >
            {t.landing.ctaButton}
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>
    </div>
  );
}

function FAQSection() {
  const { t } = useLanguage();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    { q: t.faq.q1, a: t.faq.a1 },
    { q: t.faq.q2, a: t.faq.a2 },
    { q: t.faq.q3, a: t.faq.a3 },
    { q: t.faq.q4, a: t.faq.a4 },
    { q: t.faq.q5, a: t.faq.a5 },
    { q: t.faq.q6, a: t.faq.a6 },
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">{t.landing.faqTitle}</h2>
          <p className="mt-3 text-lg text-gray-600">{t.landing.faqSubtitle}</p>
        </div>
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div key={i} className="rounded-xl bg-white border border-gray-100 overflow-hidden">
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-5 text-left hover:bg-gray-50 transition-colors"
              >
                <span className="font-medium text-gray-900">{faq.q}</span>
                <ChevronDown
                  className={`w-5 h-5 text-gray-400 flex-shrink-0 transition-transform ${
                    openIndex === i ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {openIndex === i && (
                <div className="px-5 pb-5 text-sm text-gray-600 leading-relaxed">{faq.a}</div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
