import { AuthProvider, useAuth } from '@/context/AuthContext';
import { LanguageProvider } from '@/context/LanguageContext';
import { RouterProvider, useRouter } from '@/lib/router';
import { Navigation } from '@/components/Navigation';
import { Footer } from '@/components/Footer';
import { LandingPage } from '@/pages/LandingPage';
import { SignInPage, SignUpPage, ResetPasswordPage } from '@/pages/AuthPages';
import { CreateListingPage } from '@/pages/CreateListingPage';
import { ResultsPage } from '@/pages/ResultsPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { PricingPage } from '@/pages/PricingPage';
import { Sparkles, Loader2 } from 'lucide-react';

function AppContent() {
  const { path } = useRouter();
  const { loading, user } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center animate-pulse">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <Loader2 className="w-5 h-5 text-teal-500 animate-spin" />
        </div>
      </div>
    );
  }

  // Route matching
  const renderPage = () => {
    if (path === '/' || path === '') return <LandingPage />;
    if (path === '/signin') {
      return user ? <DashboardPage /> : <SignInPage />;
    }
    if (path === '/signup') {
      return user ? <DashboardPage /> : <SignUpPage />;
    }
    if (path === '/reset-password') return <ResetPasswordPage />;
    if (path === '/pricing') return <PricingPage />;
    if (path === '/create') {
      return user ? <CreateListingPage /> : <SignInPage />;
    }
    if (path === '/dashboard') {
      return user ? <DashboardPage /> : <SignInPage />;
    }
    if (path.startsWith('/results/')) {
      const id = path.replace('/results/', '');
      return user ? <ResultsPage listingId={id} /> : <SignInPage />;
    }
    return <LandingPage />;
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navigation />
      <main className="flex-1">{renderPage()}</main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <RouterProvider>
          <AppContent />
        </RouterProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}

export default App;
