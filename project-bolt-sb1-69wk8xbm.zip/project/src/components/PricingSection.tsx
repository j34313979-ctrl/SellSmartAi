import { Check, Sparkles } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { useAuth } from '@/context/AuthContext';
import { navigate } from '@/lib/router';

export function PricingSection() {
  const { t } = useLanguage();
  const { user, credits } = useAuth();

  const currentPlan = credits?.plan ?? 'free';

  const plans = [
    {
      name: t.pricing.free,
      price: t.pricing.freePrice,
      period: t.pricing.freePeriod,
      desc: t.pricing.freeDesc,
      features: [
        t.pricing.freeFeature1,
        t.pricing.freeFeature2,
        t.pricing.freeFeature3,
        t.pricing.freeFeature4,
      ],
      cta: t.pricing.freeCta,
      planKey: 'free',
      highlight: false,
    },
    {
      name: t.pricing.pro,
      price: t.pricing.proPrice,
      period: t.pricing.proPeriod,
      desc: t.pricing.proDesc,
      features: [
        t.pricing.proFeature1,
        t.pricing.proFeature2,
        t.pricing.proFeature3,
        t.pricing.proFeature4,
        t.pricing.proFeature5,
        t.pricing.proFeature6,
      ],
      cta: t.pricing.proCta,
      planKey: 'pro',
      highlight: true,
    },
    {
      name: t.pricing.payg,
      price: t.pricing.paygPrice,
      period: t.pricing.paygPeriod,
      desc: t.pricing.paygDesc,
      features: [
        t.pricing.paygFeature1,
        t.pricing.paygFeature2,
        t.pricing.paygFeature3,
      ],
      cta: t.pricing.paygCta,
      planKey: 'payg',
      highlight: false,
    },
  ];

  const handleCta = (planKey: string) => {
    if (!user) {
      navigate('/signup');
      return;
    }
    // For now, payment is not required - just show an alert-like state
    // In the future, this will integrate with Stripe
    navigate('/pricing');
  };

  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">{t.landing.pricingTitle}</h2>
          <p className="mt-3 text-lg text-gray-600">{t.landing.pricingSubtitle}</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto items-start">
          {plans.map((plan) => (
            <div
              key={plan.planKey}
              className={`relative rounded-2xl p-8 ${
                plan.highlight
                  ? 'bg-gradient-to-b from-teal-500 to-cyan-600 text-white shadow-2xl shadow-teal-500/20 md:scale-105'
                  : 'bg-white border border-gray-200 shadow-sm'
              }`}
            >
              {plan.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-white text-teal-600 text-xs font-semibold shadow-md">
                  {t.pricing.mostPopular}
                </div>
              )}
              <h3 className={`text-lg font-semibold ${plan.highlight ? 'text-white' : 'text-gray-900'}`}>
                {plan.name}
              </h3>
              <div className="mt-2 flex items-baseline gap-1">
                <span className={`text-4xl font-bold ${plan.highlight ? 'text-white' : 'text-gray-900'}`}>
                  {plan.price}
                </span>
                <span className={`text-sm ${plan.highlight ? 'text-teal-100' : 'text-gray-500'}`}>
                  {plan.period}
                </span>
              </div>
              <p className={`mt-2 text-sm ${plan.highlight ? 'text-teal-50' : 'text-gray-500'}`}>
                {plan.desc}
              </p>
              <ul className="mt-6 space-y-3">
                {plan.features.map((f, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <Check
                      className={`w-5 h-5 flex-shrink-0 ${plan.highlight ? 'text-teal-200' : 'text-teal-500'}`}
                    />
                    <span className={`text-sm ${plan.highlight ? 'text-teal-50' : 'text-gray-600'}`}>
                      {f}
                    </span>
                  </li>
                ))}
              </ul>
              <button
                onClick={() => handleCta(plan.planKey)}
                disabled={!!user && currentPlan === plan.planKey}
                className={`mt-8 w-full py-3 rounded-xl font-semibold text-sm transition-all ${
                  user && currentPlan === plan.planKey
                    ? plan.highlight
                      ? 'bg-white/20 text-white/70 cursor-default'
                      : 'bg-gray-100 text-gray-400 cursor-default'
                    : plan.highlight
                    ? 'bg-white text-teal-600 hover:bg-teal-50 shadow-md'
                    : 'bg-gray-900 text-white hover:bg-gray-800'
                }`}
              >
                {user && currentPlan === plan.planKey ? t.pricing.currentPlan : plan.cta}
              </button>
            </div>
          ))}
        </div>
        {user && (
          <div className="mt-8 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-teal-50 border border-teal-100">
              <Sparkles className="w-4 h-4 text-teal-600" />
              <span className="text-sm font-medium text-teal-700">
                {(credits?.free_credits ?? 0) + (credits?.paid_credits ?? 0)} {t.nav.credits}
              </span>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
