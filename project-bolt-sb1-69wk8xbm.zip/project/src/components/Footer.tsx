import { Sparkles } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { navigate } from '@/lib/router';

export function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="bg-gray-900 text-gray-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-lg text-white">SellSmart AI</span>
            </div>
            <p className="text-sm">{t.footer.tagline}</p>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-3 text-sm">{t.footer.product}</h4>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => navigate('/create')} className="hover:text-white transition-colors">{t.nav.create}</button></li>
              <li><button onClick={() => navigate('/pricing')} className="hover:text-white transition-colors">{t.nav.pricing}</button></li>
              <li><button onClick={() => navigate('/dashboard')} className="hover:text-white transition-colors">{t.nav.dashboard}</button></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-3 text-sm">{t.footer.company}</h4>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => navigate('/')} className="hover:text-white transition-colors">{t.nav.home}</button></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-3 text-sm">{t.footer.legal}</h4>
            <ul className="space-y-2 text-sm">
              <li><span className="hover:text-white transition-colors cursor-pointer">Privacy</span></li>
              <li><span className="hover:text-white transition-colors cursor-pointer">Terms</span></li>
            </ul>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-800 text-sm text-center">
          &copy; {new Date().getFullYear()} SellSmart AI. {t.footer.rights}
        </div>
      </div>
    </footer>
  );
}
