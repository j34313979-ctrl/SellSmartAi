import { useState } from 'react';
import { Menu, X, Sparkles, Globe } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useLanguage } from '@/context/LanguageContext';
import { navigate } from '@/lib/router';

export function Navigation() {
  const { user, signOut, credits } = useAuth();
  const { lang, setLang, t } = useLanguage();
  const [mobileOpen, setMobileOpen] = useState(false);

  const totalCredits = (credits?.free_credits ?? 0) + (credits?.paid_credits ?? 0);

  const navLink = (label: string, path: string) => (
    <button
      onClick={() => {
        navigate(path);
        setMobileOpen(false);
      }}
      className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
    >
      {label}
    </button>
  );

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button onClick={() => navigate('/')} className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-lg text-gray-900">SellSmart AI</span>
          </button>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLink(t.nav.home, '/')}
            {user && navLink(t.nav.create, '/create')}
            {user && navLink(t.nav.dashboard, '/dashboard')}
            {navLink(t.nav.pricing, '/pricing')}
          </div>

          {/* Right side */}
          <div className="hidden md:flex items-center gap-4">
            {/* Language switcher */}
            <div className="flex items-center gap-1 bg-gray-100 rounded-full p-1">
              <Globe className="w-4 h-4 text-gray-400 ml-2" />
              <button
                onClick={() => setLang('en')}
                className={`px-2 py-0.5 text-xs font-medium rounded-full transition-colors ${
                  lang === 'en' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLang('fr')}
                className={`px-2 py-0.5 text-xs font-medium rounded-full transition-colors ${
                  lang === 'fr' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500'
                }`}
              >
                FR
              </button>
            </div>

            {/* Credits */}
            {user && (
              <div className="flex items-center gap-1.5 text-sm">
                <Sparkles className="w-4 h-4 text-teal-500" />
                <span className="font-medium text-gray-700">
                  {totalCredits} {t.nav.credits}
                </span>
              </div>
            )}

            {/* Auth */}
            {user ? (
              <button
                onClick={signOut}
                className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
              >
                {t.nav.signOut}
              </button>
            ) : (
              <div className="flex items-center gap-3">
                <button
                  onClick={() => navigate('/signin')}
                  className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
                >
                  {t.nav.signIn}
                </button>
                <button
                  onClick={() => navigate('/signup')}
                  className="text-sm font-medium px-4 py-2 rounded-lg bg-gradient-to-r from-teal-500 to-cyan-600 text-white hover:from-teal-600 hover:to-cyan-700 transition-all shadow-sm"
                >
                  {t.nav.signUp}
                </button>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="md:hidden border-t border-gray-100 py-4 space-y-3">
            <div className="flex flex-col gap-3">
              {navLink(t.nav.home, '/')}
              {user && navLink(t.nav.create, '/create')}
              {user && navLink(t.nav.dashboard, '/dashboard')}
              {navLink(t.nav.pricing, '/pricing')}
            </div>
            <div className="flex items-center gap-2 pt-3 border-t border-gray-100">
              <Globe className="w-4 h-4 text-gray-400" />
              <button
                onClick={() => setLang('en')}
                className={`px-3 py-1 text-sm font-medium rounded-lg ${
                  lang === 'en' ? 'bg-teal-50 text-teal-700' : 'text-gray-500'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLang('fr')}
                className={`px-3 py-1 text-sm font-medium rounded-lg ${
                  lang === 'fr' ? 'bg-teal-50 text-teal-700' : 'text-gray-500'
                }`}
              >
                FR
              </button>
            </div>
            {user && (
              <div className="flex items-center gap-1.5 text-sm pt-2">
                <Sparkles className="w-4 h-4 text-teal-500" />
                <span className="font-medium text-gray-700">
                  {totalCredits} {t.nav.credits}
                </span>
              </div>
            )}
            <div className="pt-3 border-t border-gray-100">
              {user ? (
                <button
                  onClick={() => {
                    signOut();
                    setMobileOpen(false);
                  }}
                  className="text-sm font-medium text-gray-600 hover:text-gray-900"
                >
                  {t.nav.signOut}
                </button>
              ) : (
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      navigate('/signin');
                      setMobileOpen(false);
                    }}
                    className="flex-1 text-sm font-medium px-4 py-2 rounded-lg border border-gray-200 text-gray-700"
                  >
                    {t.nav.signIn}
                  </button>
                  <button
                    onClick={() => {
                      navigate('/signup');
                      setMobileOpen(false);
                    }}
                    className="flex-1 text-sm font-medium px-4 py-2 rounded-lg bg-gradient-to-r from-teal-500 to-cyan-600 text-white"
                  >
                    {t.nav.signUp}
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
