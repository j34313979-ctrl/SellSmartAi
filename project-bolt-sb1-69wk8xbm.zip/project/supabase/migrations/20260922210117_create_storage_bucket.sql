/*
# Create storage bucket for listing photos

## Overview
Creates a public storage bucket for user-uploaded listing photos and sets up storage policies so authenticated users can upload and read photos.

## Changes
- Create 'listing-photos' bucket (public)
- Add storage policies for authenticated users to manage their own photos
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('listing-photos', 'listing-photos', true)
ON CONFLICT (id) DO NOTHING;

-- Allow authenticated users to upload to listing-photos
DROP POLICY IF EXISTS "Authenticated users can upload listing photos" ON storage.objects;
CREATE POLICY "Authenticated users can upload listing photos"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'listing-photos');

-- Allow anyone to read listing photos (public bucket)
DROP POLICY IF EXISTS "Anyone can read listing photos" ON storage.objects;
CREATE POLICY "Anyone can read listing photos"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'listing-photos');

-- Allow authenticated users to update their own photos
DROP POLICY IF EXISTS "Authenticated users can update listing photos" ON storage.objects;
CREATE POLICY "Authenticated users can update listing photos"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'listing-photos');

-- Allow authenticated users to delete their own photos
DROP POLICY IF EXISTS "Authenticated users can delete listing photos" ON storage.objects;
CREATE POLICY "Authenticated users can delete listing photos"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'listing-photos');