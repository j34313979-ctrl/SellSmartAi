/*
# SellSmart AI - Core Database Schema

## Overview
Creates the complete database structure for the SellSmart AI application:
- Listings: stores user-generated AI listings with all generated content
- Credits: tracks free and paid AI generation credits per user
- Subscriptions: tracks subscription plans and status

## New Tables

### listings
- id (uuid, primary key)
- user_id (uuid, references auth.users, defaults to auth.uid())
- product_name (text) - AI-identified product name
- title (text) - recommended listing title
- alternative_titles (jsonb) - 5 alternative titles
- description (text) - complete selling description
- short_description (text) - short description
- recommended_price (numeric) - suggested price
- price_range_min (numeric) - expected selling range min
- price_range_max (numeric) - expected selling range max
- category (text) - suggested category
- keywords (jsonb) - relevant keywords array
- suggested_condition (text) - AI suggested condition
- buyer_qa (jsonb) - suggested buyer questions and answers
- negotiation_price (numeric) - suggested negotiation price
- minimum_price (numeric) - suggested minimum acceptable price
- platform_formats (jsonb) - formatted listings per platform
- input_brand (text) - user-provided brand
- input_model (text) - user-provided model
- input_condition (text) - user-provided condition
- input_location (text) - user-provided location
- input_language (text) - desired output language
- input_description (text) - user-provided item description
- image_urls (jsonb) - array of uploaded image URLs
- status (text) - draft/published/archived
- created_at (timestamptz)
- updated_at (timestamptz)

### credits
- id (uuid, primary key)
- user_id (uuid, references auth.users, defaults to auth.uid())
- free_credits (integer) - free generation credits remaining
- paid_credits (integer) - paid generation credits remaining
- plan (text) - free/pro
- created_at (timestamptz)
- updated_at (timestamptz)

### subscriptions
- id (uuid, primary key)
- user_id (uuid, references auth.users, defaults to auth.uid())
- plan (text) - free/pro/pay_as_you_go
- status (text) - active/canceled/expired
- stripe_customer_id (text) - for future Stripe integration
- stripe_subscription_id (text) - for future Stripe integration
- current_period_start (timestamptz)
- current_period_end (timestamptz)
- created_at (timestamptz)
- updated_at (timestamptz)

## Security
- RLS enabled on all tables
- Owner-scoped CRUD policies (authenticated users can only access their own rows)
- user_id columns default to auth.uid() so inserts work without explicitly passing user_id
*/

-- Listings table
CREATE TABLE IF NOT EXISTS listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  product_name text,
  title text,
  alternative_titles jsonb DEFAULT '[]'::jsonb,
  description text,
  short_description text,
  recommended_price numeric(10,2),
  price_range_min numeric(10,2),
  price_range_max numeric(10,2),
  category text,
  keywords jsonb DEFAULT '[]'::jsonb,
  suggested_condition text,
  buyer_qa jsonb DEFAULT '[]'::jsonb,
  negotiation_price numeric(10,2),
  minimum_price numeric(10,2),
  platform_formats jsonb DEFAULT '{}'::jsonb,
  input_brand text,
  input_model text,
  input_condition text,
  input_location text,
  input_language text DEFAULT 'en',
  input_description text,
  image_urls jsonb DEFAULT '[]'::jsonb,
  status text DEFAULT 'draft',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE listings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_listings" ON listings;
CREATE POLICY "select_own_listings" ON listings FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_listings" ON listings;
CREATE POLICY "insert_own_listings" ON listings FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_listings" ON listings;
CREATE POLICY "update_own_listings" ON listings FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_listings" ON listings;
CREATE POLICY "delete_own_listings" ON listings FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Credits table
CREATE TABLE IF NOT EXISTS credits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  free_credits integer NOT NULL DEFAULT 3,
  paid_credits integer NOT NULL DEFAULT 0,
  plan text NOT NULL DEFAULT 'free',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE credits ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_credits" ON credits;
CREATE POLICY "select_own_credits" ON credits FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_credits" ON credits;
CREATE POLICY "insert_own_credits" ON credits FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_credits" ON credits;
CREATE POLICY "update_own_credits" ON credits FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_credits" ON credits;
CREATE POLICY "delete_own_credits" ON credits FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan text NOT NULL DEFAULT 'free',
  status text NOT NULL DEFAULT 'active',
  stripe_customer_id text,
  stripe_subscription_id text,
  current_period_start timestamptz,
  current_period_end timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_subscriptions" ON subscriptions;
CREATE POLICY "select_own_subscriptions" ON subscriptions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_subscriptions" ON subscriptions;
CREATE POLICY "insert_own_subscriptions" ON subscriptions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_subscriptions" ON subscriptions;
CREATE POLICY "update_own_subscriptions" ON subscriptions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_subscriptions" ON subscriptions;
CREATE POLICY "delete_own_subscriptions" ON subscriptions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_listings_user_id ON listings(user_id);
CREATE INDEX IF NOT EXISTS idx_listings_created_at ON listings(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_credits_user_id ON credits(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON subscriptions(user_id);

-- Function to automatically update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_listings_updated_at ON listings;
CREATE TRIGGER update_listings_updated_at BEFORE UPDATE ON listings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_credits_updated_at ON credits;
CREATE TRIGGER update_credits_updated_at BEFORE UPDATE ON credits
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_subscriptions_updated_at ON subscriptions;
CREATE TRIGGER update_subscriptions_updated_at BEFORE UPDATE ON subscriptions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to automatically create credits row for new users
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO credits (user_id, free_credits, paid_credits, plan)
  VALUES (NEW.id, 3, 0, 'free');
  
  INSERT INTO subscriptions (user_id, plan, status)
  VALUES (NEW.id, 'free', 'active');
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();