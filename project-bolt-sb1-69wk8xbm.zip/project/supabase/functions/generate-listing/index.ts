import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const {
      images,
      brand,
      model,
      condition,
      location,
      language,
      description,
    } = body;

    if (!images || !Array.isArray(images) || images.length === 0) {
      return new Response(
        JSON.stringify({ error: "At least one image is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check for OpenAI API key
    const openaiApiKey = Deno.env.get("OPENAI_API_KEY");

    if (!openaiApiKey) {
      // Return a structured response indicating AI is not configured
      // This lets the app work in a "demo mode" without an API key
      return new Response(
        JSON.stringify({
          error: "AI_API_NOT_CONFIGURED",
          message: "The AI API key is not configured. Please add OPENAI_API_KEY to the edge function secrets.",
        }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Call OpenAI Vision API to analyze the images
    const visionResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${openaiApiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are an expert at analyzing items for sale from photos and creating optimized selling listings. You must respond in ${language === "fr" ? "French" : "English"}.`,
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `Analyze these photos of an item for sale and generate a complete optimized selling listing.

User-provided details (may be empty):
- What they're selling: ${description || "Not specified"}
- Brand: ${brand || "Not specified"}
- Model: ${model || "Not specified"}
- Condition: ${condition || "Not specified"}
- Location: ${location || "Not specified"}
- Desired language: ${language === "fr" ? "French" : "English"}

IMPORTANT INSTRUCTIONS:
1. Identify the product from the photos. If you cannot confidently identify it, say so clearly.
2. Do not make unrealistic claims about condition.
3. Make the writing natural and human.
4. Generate realistic price estimates based on the item and market data.

Return your response as a JSON object with this exact structure:
{
  "product_name": "What you think the item is (include 'Please verify' if uncertain)",
  "title": "Optimized listing title (max 80 chars, include brand, model, key features)",
  "alternative_titles": ["5 alternative titles, each different angle/keyword focus"],
  "description": "Complete selling description (3-5 paragraphs, natural tone, highlight features and condition honestly)",
  "short_description": "1-2 sentence summary",
  "recommended_price": 0,
  "price_range_min": 0,
  "price_range_max": 0,
  "category": "Suggested category",
  "keywords": ["relevant", "search", "keywords"],
  "suggested_condition": "Your assessment of condition based on photos",
  "buyer_qa": [
    {"question": "Is this still available?", "answer": "Suggested response"},
    {"question": "What's your lowest price?", "answer": "Suggested response"},
    {"question": "Can you deliver?", "answer": "Suggested response"},
    {"question": "Any damage?", "answer": "Suggested response"},
    {"question": "Why are you selling it?", "answer": "Suggested response"}
  ],
  "negotiation_price": 0,
  "minimum_price": 0,
  "platform_formats": {
    "facebook": "Formatted listing for Facebook Marketplace",
    "kijiji": "Formatted listing for Kijiji",
    "ebay": "Formatted listing for eBay",
    "craigslist": "Formatted listing for Craigslist",
    "vinted": "Formatted listing for Vinted"
  }
}

Return ONLY the JSON object, no markdown, no explanation outside the JSON.`,
              },
              ...images.slice(0, 5).map((url: string) => ({
                type: "image_url",
                image_url: { url },
              })),
            ],
          },
        ],
        max_tokens: 4000,
        temperature: 0.7,
        response_format: { type: "json_object" },
      }),
    });

    if (!visionResponse.ok) {
      const errText = await visionResponse.text();
      throw new Error(`OpenAI API error: ${visionResponse.status} - ${errText}`);
    }

    const visionData = await visionResponse.json();
    const content = visionData.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error("No content returned from AI");
    }

    let result;
    try {
      result = JSON.parse(content);
    } catch {
      // If JSON parsing fails, try to extract JSON from the content
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        result = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("Failed to parse AI response as JSON");
      }
    }

    // Ensure all required fields exist
    const listing = {
      product_name: result.product_name || "Unable to identify — please verify",
      title: result.title || "Item for sale",
      alternative_titles: Array.isArray(result.alternative_titles) ? result.alternative_titles : [],
      description: result.description || "",
      short_description: result.short_description || "",
      recommended_price: Number(result.recommended_price) || 0,
      price_range_min: Number(result.price_range_min) || 0,
      price_range_max: Number(result.price_range_max) || 0,
      category: result.category || "General",
      keywords: Array.isArray(result.keywords) ? result.keywords : [],
      suggested_condition: result.suggested_condition || condition || "Good",
      buyer_qa: Array.isArray(result.buyer_qa) ? result.buyer_qa : [],
      negotiation_price: Number(result.negotiation_price) || 0,
      minimum_price: Number(result.minimum_price) || 0,
      platform_formats: result.platform_formats || {},
    };

    return new Response(JSON.stringify(listing), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
