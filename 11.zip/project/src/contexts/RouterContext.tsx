import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';

type Route = 'home' | 'create' | 'results' | 'dashboard' | 'pricing' | 'signin' | 'signup' | 'reset';

interface RouterContextValue {
  route: Route;
  params: Record<string, string>;
  navigate: (route: Route, params?: Record<string, string>) => void;
}

const RouterContext = createContext<RouterContextValue | undefined>(undefined);

export function RouterProvider({ children }: { children: ReactNode }) {
  const [route, setRoute] = useState<Route>('home');
  const [params, setParams] = useState<Record<string, string>>({});

  const navigate = useCallback((newRoute: Route, newParams: Record<string, string> = {}) => {
    setRoute(newRoute);
    setParams(newParams);
    window.scrollTo(0, 0);
  }, []);

  return (
    <RouterContext.Provider value={{ route, params, navigate }}>
      {children}
    </RouterContext.Provider>
  );
}

export function useRouter() {
  const ctx = useContext(RouterContext);
  if (!ctx) throw new Error('useRouter must be used within RouterProvider');
  return ctx;
}

export type { Route };
