import { AuthProvider } from '@/contexts/AuthContext';
import { LanguageProvider } from '@/contexts/LanguageContext';
import { RouterProvider, useRouter } from '@/contexts/RouterContext';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { HomePage } from '@/pages/HomePage';
import { CreatePage } from '@/pages/CreatePage';
import { ResultsPage } from '@/pages/ResultsPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { AuthPage } from '@/pages/AuthPage';
import { PricingPage } from '@/pages/PricingPage';

function AppContent() {
  const { route } = useRouter();

  const showChrome = route !== 'signin' && route !== 'signup' && route !== 'reset';

  return (
    <div className="flex min-h-screen flex-col bg-white">
      {showChrome && <Navbar />}
      <main className="flex-1">
        {route === 'home' && <HomePage />}
        {route === 'create' && <CreatePage />}
        {route === 'results' && <ResultsPage />}
        {route === 'dashboard' && <DashboardPage />}
        {route === 'pricing' && <PricingPage />}
        {route === 'signin' && <AuthPage mode="signin" />}
        {route === 'signup' && <AuthPage mode="signup" />}
        {route === 'reset' && <AuthPage mode="reset" />}
      </main>
      {showChrome && <Footer />}
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <RouterProvider>
          <AppContent />
        </RouterProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}
