import { useState, useEffect } from 'react';
import {
  Package, DollarSign, Tag, FileText, MessageSquare, Share2,
  AlertCircle, ArrowLeft, Plus, Check, Loader2, Hash, ListChecks,
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRouter } from '@/contexts/RouterContext';
import { supabase } from '@/lib/supabase';
import { CopyButton } from '@/components/CopyButton';
import { formatForPlatform } from '@/lib/platforms';
import type { GeneratedContent, Platform, Listing } from '@/types';

const PLATFORMS: Platform[] = ['facebook', 'kijiji', 'ebay', 'craigslist', 'vinted'];
const platformKey = (p: Platform) => `platform_${p}` as 'platform_facebook';

export function ResultsPage() {
  const { t } = useLanguage();
  const { params, navigate } = useRouter();
  const [content, setContent] = useState<GeneratedContent | null>(null);
  const [listing, setListing] = useState<Listing | null>(null);
  const [loading, setLoading] = useState(true);
  const [activePlatform, setActivePlatform] = useState<Platform>('facebook');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      const listingId = params.listingId;

      // Try to get content from params first (just generated)
      if (params.content) {
        try {
          setContent(JSON.parse(params.content));
        } catch {
          // ignore parse error
        }
      }

      if (listingId) {
        const { data, error: fetchError } = await supabase
          .from('listings')
          .select('*')
          .eq('id', listingId)
          .maybeSingle();

        if (fetchError || !data) {
          setError(t('error_loading'));
          setLoading(false);
          return;
        }

        setListing(data as Listing);

        // If no content from params, use stored content
        if (!params.content && (data as Listing).generated_content) {
          setContent((data as Listing).generated_content);
        }
      }

      setLoading(false);
    };

    load();
  }, [params.listingId, params.content, t]);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-teal-600" />
      </div>
    );
  }

  if (error || !content) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-20 text-center">
        <AlertCircle className="mx-auto h-12 w-12 text-slate-300" />
        <p className="mt-4 text-slate-500">{error || t('error_loading')}</p>
        <button
          onClick={() => navigate('dashboard')}
          className="mt-6 rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white"
        >
          {t('results_back_dashboard')}
        </button>
      </div>
    );
  }

  const platformText = formatForPlatform(content, activePlatform);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <button
            onClick={() => navigate('dashboard')}
            className="flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-900"
          >
            <ArrowLeft className="h-4 w-4" />
            {t('results_back_dashboard')}
          </button>
          <h1 className="mt-2 text-2xl font-bold tracking-tight text-slate-900">{t('results_title')}</h1>
        </div>
        <button
          onClick={() => navigate('create')}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-teal-600 to-cyan-600 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-teal-500/25 transition-all hover:shadow-xl"
        >
          <Plus className="h-4 w-4" />
          {t('results_new')}
        </button>
      </div>

      {/* Product identification */}
      <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex items-center gap-2 text-slate-500">
          <Package className="h-5 w-5" />
          <span className="text-sm font-semibold uppercase tracking-wide">{t('results_product')}</span>
        </div>
        <p className="mt-3 text-lg font-medium text-slate-900">{content.product_identification}</p>
        {content.suggested_condition && (
          <div className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-3 py-1.5 text-sm text-slate-700">
            <Check className="h-4 w-4 text-teal-600" />
            {t('results_condition')}: {content.suggested_condition}
          </div>
        )}
      </div>

      {/* Price */}
      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-gradient-to-br from-teal-50 to-cyan-50 p-6">
          <div className="flex items-center gap-2 text-teal-700">
            <DollarSign className="h-5 w-5" />
            <span className="text-sm font-semibold uppercase tracking-wide">{t('results_price')}</span>
          </div>
          <div className="mt-4">
            <p className="text-sm text-slate-500">{t('results_suggested')}</p>
            <p className="text-4xl font-bold text-slate-900">${content.recommended_price}</p>
          </div>
          <div className="mt-4 border-t border-teal-200 pt-4">
            <p className="text-sm text-slate-500">{t('results_range')}</p>
            <p className="text-xl font-semibold text-teal-700">
              ${content.price_range_low} – ${content.price_range_high}
            </p>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-6">
          <div className="flex items-center gap-2 text-slate-500">
            <ListChecks className="h-5 w-5" />
            <span className="text-sm font-semibold uppercase tracking-wide">Pricing Details</span>
          </div>
          <div className="mt-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">{t('results_negotiation')}</span>
              <span className="font-semibold text-slate-900">${content.negotiation_price}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">{t('results_minimum')}</span>
              <span className="font-semibold text-slate-900">${content.minimum_acceptable_price}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">{t('results_category')}</span>
              <span className="font-semibold text-slate-900">{content.suggested_category}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Price disclaimer */}
      <div className="mt-4 flex items-start gap-2 rounded-xl bg-amber-50 border border-amber-200 px-4 py-3">
        <AlertCircle className="h-5 w-5 flex-shrink-0 text-amber-600" />
        <p className="text-sm text-amber-800">{t('results_disclaimer')}</p>
      </div>

      {/* Optimized Title */}
      <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-500">
            <Tag className="h-5 w-5" />
            <span className="text-sm font-semibold uppercase tracking-wide">{t('results_title_label')}</span>
          </div>
          <CopyButton text={content.recommended_title} label={t('results_copy')} />
        </div>
        <p className="mt-3 text-lg font-semibold text-slate-900">{content.recommended_title}</p>
      </div>

      {/* Alternative titles */}
      <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex items-center gap-2 text-slate-500">
          <ListChecks className="h-5 w-5" />
          <span className="text-sm font-semibold uppercase tracking-wide">{t('results_alt_titles')}</span>
        </div>
        <div className="mt-4 space-y-3">
          {content.alternative_titles?.map((title, i) => (
            <div key={i} className="flex items-center justify-between gap-3 rounded-lg bg-slate-50 px-4 py-3">
              <p className="text-sm text-slate-700">{title}</p>
              <CopyButton text={title} label={t('results_copy')} />
            </div>
          ))}
        </div>
      </div>

      {/* Description */}
      <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-500">
            <FileText className="h-5 w-5" />
            <span className="text-sm font-semibold uppercase tracking-wide">{t('results_description')}</span>
          </div>
          <CopyButton text={content.full_description} label={t('results_copy')} />
        </div>
        <div className="mt-3 whitespace-pre-wrap text-sm leading-relaxed text-slate-700">
          {content.full_description}
        </div>
      </div>

      {/* Short description */}
      <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-500">
            <FileText className="h-5 w-5" />
            <span className="text-sm font-semibold uppercase tracking-wide">{t('results_short_desc')}</span>
          </div>
          <CopyButton text={content.short_description} label={t('results_copy')} />
        </div>
        <p className="mt-3 text-sm text-slate-700">{content.short_description}</p>
      </div>

      {/* Keywords */}
      <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex items-center gap-2 text-slate-500">
          <Hash className="h-5 w-5" />
          <span className="text-sm font-semibold uppercase tracking-wide">{t('results_keywords')}</span>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {content.keywords?.map((kw, i) => (
            <span key={i} className="rounded-full bg-teal-50 px-3 py-1 text-sm font-medium text-teal-700">
              {kw}
            </span>
          ))}
        </div>
      </div>

      {/* Buyer replies */}
      <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex items-center gap-2 text-slate-500">
          <MessageSquare className="h-5 w-5" />
          <span className="text-sm font-semibold uppercase tracking-wide">{t('results_buyer_replies')}</span>
        </div>
        <div className="mt-4 space-y-4">
          {content.buyer_qa?.map((qa, i) => (
            <div key={i} className="rounded-xl bg-slate-50 p-4">
              <p className="font-medium text-slate-900">{qa.question}</p>
              <div className="mt-2 flex items-start justify-between gap-3">
                <p className="text-sm text-slate-600">{qa.answer}</p>
                <CopyButton text={qa.answer} label={t('results_copy')} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Platform formatting */}
      <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-6">
        <div className="flex items-center gap-2 text-slate-500">
          <Share2 className="h-5 w-5" />
          <span className="text-sm font-semibold uppercase tracking-wide">{t('results_platforms')}</span>
        </div>
        {/* Tabs */}
        <div className="mt-4 flex flex-wrap gap-2 border-b border-slate-200 pb-2">
          {PLATFORMS.map((p) => (
            <button
              key={p}
              onClick={() => setActivePlatform(p)}
              className={`rounded-lg px-4 py-2 text-sm font-medium transition-all ${
                activePlatform === p
                  ? 'bg-teal-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {t(platformKey(p))}
            </button>
          ))}
        </div>
        {/* Content */}
        <div className="mt-4">
          <div className="flex items-center justify-end mb-2">
            <CopyButton text={platformText} label={t('results_copy')} />
          </div>
          <div className="rounded-xl bg-slate-50 p-4">
            <pre className="whitespace-pre-wrap text-sm leading-relaxed text-slate-700 font-sans">
              {platformText}
            </pre>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <button
          onClick={() => navigate('create')}
          className="flex-1 rounded-xl bg-gradient-to-r from-teal-600 to-cyan-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-teal-500/25 transition-all hover:shadow-xl"
        >
          {t('results_new')}
        </button>
        <button
          onClick={() => navigate('dashboard')}
          className="flex-1 rounded-xl border border-slate-300 bg-white px-6 py-3 text-sm font-semibold text-slate-700 transition-all hover:bg-slate-50"
        >
          {t('results_back_dashboard')}
        </button>
      </div>
    </div>
  );
}
