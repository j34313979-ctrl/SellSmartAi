import { useState } from 'react';
import { Sparkles, Mail, Lock, AlertCircle, ArrowLeft, Check } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from '@/contexts/RouterContext';

type AuthMode = 'signin' | 'signup' | 'reset';

export function AuthPage({ mode }: { mode: AuthMode }) {
  const { t } = useLanguage();
  const { signIn, signUp, resetPassword } = useAuth();
  const { navigate } = useRouter();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  const titles: Record<AuthMode, string> = {
    signin: t('auth_signin_title'),
    signup: t('auth_signup_title'),
    reset: t('auth_reset_title'),
  };

  const subtitles: Record<AuthMode, string> = {
    signin: t('auth_signin_subtitle'),
    signup: t('auth_signup_subtitle'),
    reset: t('auth_reset_subtitle'),
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (mode === 'signin') {
        const { error: err } = await signIn(email, password);
        if (err) {
          setError(err.includes('Invalid') ? t('auth_error_invalid') : err);
        } else {
          navigate('dashboard');
        }
      } else if (mode === 'signup') {
        if (password !== confirmPassword) {
          setError(t('auth_error_weak'));
          setLoading(false);
          return;
        }
        if (password.length < 6) {
          setError(t('auth_error_weak'));
          setLoading(false);
          return;
        }
        const { error: err } = await signUp(email, password);
        if (err) {
          setError(err.includes('already') ? t('auth_error_exists') : err);
        } else {
          navigate('dashboard');
        }
      } else if (mode === 'reset') {
        const { error: err } = await resetPassword(email);
        if (err) {
          setError(err);
        } else {
          setResetSent(true);
        }
      }
    } catch {
      setError(t('auth_error_generic'));
    }

    setLoading(false);
  };

  return (
    <div className="flex min-h-[80vh] items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center">
          <button onClick={() => navigate('home')} className="inline-flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-cyan-600">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold text-slate-900">
              SellSmart<span className="text-teal-600"> AI</span>
            </span>
          </button>
        </div>

        <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">{titles[mode]}</h1>
          <p className="mt-2 text-sm text-slate-500">{subtitles[mode]}</p>

          {resetSent ? (
            <div className="mt-6 flex items-center gap-2 rounded-xl bg-green-50 border border-green-200 px-4 py-3">
              <Check className="h-5 w-5 text-green-600" />
              <p className="text-sm text-green-700">{t('auth_reset_sent')}</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700">{t('auth_email')}</label>
                <div className="relative mt-1">
                  <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 py-2.5 pl-10 pr-4 text-sm text-slate-900 outline-none transition-all focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20"
                    placeholder="you@example.com"
                  />
                </div>
              </div>

              {mode !== 'reset' && (
                <div>
                  <label className="block text-sm font-medium text-slate-700">{t('auth_password')}</label>
                  <div className="relative mt-1">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 py-2.5 pl-10 pr-4 text-sm text-slate-900 outline-none transition-all focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20"
                      placeholder="••••••••"
                    />
                  </div>
                </div>
              )}

              {mode === 'signup' && (
                <div>
                  <label className="block text-sm font-medium text-slate-700">{t('auth_confirm_password')}</label>
                  <div className="relative mt-1">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 py-2.5 pl-10 pr-4 text-sm text-slate-900 outline-none transition-all focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20"
                      placeholder="••••••••"
                    />
                  </div>
                </div>
              )}

              {error && (
                <div className="flex items-center gap-2 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
                  <AlertCircle className="h-5 w-5 flex-shrink-0" />
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-xl bg-gradient-to-r from-teal-600 to-cyan-600 py-3 text-sm font-semibold text-white shadow-lg shadow-teal-500/25 transition-all hover:shadow-xl disabled:opacity-50"
              >
                {loading
                  ? t('loading')
                  : mode === 'signin'
                  ? t('auth_signin_btn')
                  : mode === 'signup'
                  ? t('auth_signup_btn')
                  : t('auth_reset_btn')}
              </button>
            </form>
          )}

          {/* Links */}
          <div className="mt-6 space-y-2 text-center text-sm">
            {mode === 'signin' && (
              <>
                <button
                  onClick={() => navigate('reset')}
                  className="text-teal-600 hover:text-teal-700 font-medium"
                >
                  {t('auth_forgot')}
                </button>
                <p className="text-slate-500">
                  {t('auth_no_account')}{' '}
                  <button onClick={() => navigate('signup')} className="font-semibold text-teal-600 hover:text-teal-700">
                    {t('auth_signup_link')}
                  </button>
                </p>
              </>
            )}
            {mode === 'signup' && (
              <p className="text-slate-500">
                {t('auth_have_account')}{' '}
                <button onClick={() => navigate('signin')} className="font-semibold text-teal-600 hover:text-teal-700">
                  {t('auth_signin_link')}
                </button>
              </p>
            )}
            {mode === 'reset' && (
              <button
                onClick={() => navigate('signin')}
                className="inline-flex items-center gap-1.5 text-teal-600 hover:text-teal-700 font-medium"
              >
                <ArrowLeft className="h-4 w-4" />
                {t('auth_back_signin')}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
