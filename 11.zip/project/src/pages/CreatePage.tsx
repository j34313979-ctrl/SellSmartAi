import { useState, useCallback, useRef } from 'react';
import { Upload, X, ImageIcon, Sparkles, AlertCircle, Loader2, ChevronRight } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from '@/contexts/RouterContext';
import { supabase, EDGE_FUNCTION_URL } from '@/lib/supabase';
import type { Condition, Language, GeneratedContent } from '@/types';

const MAX_IMAGES = 5;

export function CreatePage() {
  const { t, lang, setLang } = useLanguage();
  const { user, session, profile, refreshProfile } = useAuth();
  const { navigate } = useRouter();

  const [images, setImages] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [itemName, setItemName] = useState('');
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [condition, setCondition] = useState<Condition | ''>('');
  const [location, setLocation] = useState('');
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const totalCredits =
    (profile?.free_credits_remaining || 0) +
    (profile?.paid_credits_remaining || 0) +
    (profile?.monthly_credits_remaining || 0);

  const handleFiles = useCallback((files: FileList | null) => {
    if (!files) return;
    const newFiles = Array.from(files).filter((f) => f.type.startsWith('image/'));
    const combined = [...images, ...newFiles].slice(0, MAX_IMAGES);
    setImages(combined);
    setPreviews(combined.map((f) => URL.createObjectURL(f)));
  }, [images]);

  const removeImage = (idx: number) => {
    const newImages = images.filter((_, i) => i !== idx);
    setImages(newImages);
    setPreviews(newImages.map((f) => URL.createObjectURL(f)));
  };

  const handleGenerate = async () => {
    setError(null);

    if (!user) {
      navigate('signin');
      return;
    }

    if (images.length === 0) {
      setError(t('create_need_photos'));
      return;
    }

    if (totalCredits <= 0) {
      navigate('pricing');
      return;
    }

    setGenerating(true);

    try {
      // Create listing record
      const { data: listing, error: listingError } = await supabase
        .from('listings')
        .insert({
          user_id: user.id,
          item_name: itemName || null,
          brand: brand || null,
          model: model || null,
          condition: condition || null,
          location: location || null,
          language: lang,
          status: 'draft',
        })
        .select()
        .single();

      if (listingError || !listing) {
        setError(t('auth_error_generic'));
        setGenerating(false);
        return;
      }

      // Upload images to storage
      const uploadPromises = images.map(async (file, idx) => {
        const ext = file.name.split('.').pop() || 'jpg';
        const path = `${user.id}/${listing.id}/${idx}.${ext}`;
        const { error: uploadError } = await supabase.storage
          .from('listing-images')
          .upload(path, file);
        if (uploadError) throw uploadError;

        // Save image record
        await supabase.from('listing_images').insert({
          listing_id: listing.id,
          storage_path: path,
          position: idx,
        });

        return path;
      });

      const storagePaths = await Promise.all(uploadPromises);

      // Call edge function
      const response = await fetch(EDGE_FUNCTION_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${session?.access_token ?? ''}`,
          apikey: import.meta.env.VITE_SUPABASE_ANON_KEY as string,
        },
        body: JSON.stringify({
          listingId: listing.id,
          images: storagePaths,
          itemName: itemName || undefined,
          brand: brand || undefined,
          model: model || undefined,
          condition: condition || undefined,
          location: location || undefined,
          language: lang,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Request failed (${response.status})`);
      }

      const data = await response.json();
      const content = data.content as GeneratedContent;

      await refreshProfile();
      setGenerating(false);
      navigate('results', { listingId: listing.id, content: JSON.stringify(content) });
    } catch (err) {
      setError(err instanceof Error ? err.message : t('auth_error_generic'));
      setGenerating(false);
    }
  };

  const conditions: Condition[] = ['new', 'like_new', 'good', 'fair', 'poor'];
  const condKey = (c: Condition) =>
    c === 'like_new' ? 'cond_like_new' : `cond_${c}`;

  if (generating) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center px-4">
        <div className="text-center">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-500 to-cyan-600">
            <Loader2 className="h-10 w-10 animate-spin text-white" />
          </div>
          <h2 className="mt-6 text-xl font-bold text-slate-900">{t('create_generating')}</h2>
          <p className="mt-2 text-sm text-slate-500">{t('create_generating_desc')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">{t('create_title')}</h1>
        {user && (
          <p className="mt-2 text-sm text-teal-600 font-semibold">
            {totalCredits} {t('nav_credits')}
          </p>
        )}
      </div>

      {error && (
        <div className="mt-6 flex items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          <AlertCircle className="h-5 w-5 flex-shrink-0" />
          {error}
        </div>
      )}

      {/* Step 1: Upload */}
      <div className="mt-10">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-teal-600 text-sm font-bold text-white">1</div>
          <div>
            <h2 className="text-lg font-semibold text-slate-900">{t('create_step1')}</h2>
            <p className="text-sm text-slate-500">{t('create_step1_desc')}</p>
          </div>
        </div>

        <div className="mt-4">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            onChange={(e) => handleFiles(e.target.files)}
            className="hidden"
          />
          {images.length === 0 ? (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex w-full flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-300 bg-slate-50 py-16 transition-all hover:border-teal-400 hover:bg-teal-50"
            >
              <Upload className="h-10 w-10 text-slate-400" />
              <p className="mt-3 text-sm font-medium text-slate-600">{t('create_upload')}</p>
              <p className="mt-1 text-xs text-slate-400">{t('create_upload_hint')}</p>
            </button>
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {previews.map((preview, idx) => (
                <div key={idx} className="relative group aspect-square overflow-hidden rounded-xl border border-slate-200">
                  <img src={preview} alt="" className="h-full w-full object-cover" />
                  <button
                    onClick={() => removeImage(idx)}
                    className="absolute right-2 top-2 rounded-full bg-black/60 p-1 text-white opacity-0 transition-opacity group-hover:opacity-100"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
              {images.length < MAX_IMAGES && (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex aspect-square items-center justify-center rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 transition-all hover:border-teal-400 hover:bg-teal-50"
                >
                  <div className="text-center">
                    <ImageIcon className="mx-auto h-8 w-8 text-slate-400" />
                    <span className="mt-1 block text-xs text-slate-500">{t('create_add_photos')}</span>
                  </div>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Step 2: Info */}
      <div className="mt-10">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-teal-600 text-sm font-bold text-white">2</div>
          <div>
            <h2 className="text-lg font-semibold text-slate-900">{t('create_step2')}</h2>
            <p className="text-sm text-slate-500">{t('create_step2_desc')}</p>
          </div>
        </div>

        <div className="mt-4 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700">{t('create_what')}</label>
            <input
              type="text"
              value={itemName}
              onChange={(e) => setItemName(e.target.value)}
              placeholder={t('create_what_placeholder')}
              className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm text-slate-900 outline-none transition-all focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20"
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-slate-700">{t('create_brand')}</label>
              <input
                type="text"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                placeholder={t('create_brand_placeholder')}
                className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm text-slate-900 outline-none transition-all focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700">{t('create_model')}</label>
              <input
                type="text"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder={t('create_model_placeholder')}
                className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm text-slate-900 outline-none transition-all focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700">{t('create_condition')}</label>
            <div className="mt-2 flex flex-wrap gap-2">
              {conditions.map((c) => (
                <button
                  key={c}
                  onClick={() => setCondition(condition === c ? '' : c)}
                  className={`rounded-lg px-4 py-2 text-sm font-medium transition-all ${
                    condition === c
                      ? 'bg-teal-600 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {t(condKey(c) as 'cond_new')}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700">{t('create_location')}</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder={t('create_location_placeholder')}
              className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm text-slate-900 outline-none transition-all focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700">{t('create_language')}</label>
            <div className="mt-2 flex gap-2">
              {(['en', 'fr'] as Language[]).map((l) => (
                <button
                  key={l}
                  onClick={() => setLang(l)}
                  className={`rounded-lg px-6 py-2 text-sm font-medium uppercase transition-all ${
                    lang === l ? 'bg-teal-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {l === 'en' ? 'English' : 'Français'}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Step 3: Generate */}
      <div className="mt-10">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-teal-600 text-sm font-bold text-white">3</div>
          <div>
            <h2 className="text-lg font-semibold text-slate-900">{t('create_step3')}</h2>
            <p className="text-sm text-slate-500">{t('create_step3_desc')}</p>
          </div>
        </div>

        <button
          onClick={handleGenerate}
          disabled={images.length === 0 || (user ? totalCredits <= 0 : false)}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-teal-600 to-cyan-600 px-6 py-4 text-base font-semibold text-white shadow-lg shadow-teal-500/25 transition-all hover:shadow-xl hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:translate-y-0"
        >
          <Sparkles className="h-5 w-5" />
          {t('create_generate')}
          <ChevronRight className="h-5 w-5" />
        </button>

        {!user && (
          <p className="mt-3 text-center text-sm text-slate-500">{t('create_signin_required')}</p>
        )}
        {user && totalCredits <= 0 && (
          <p className="mt-3 text-center text-sm text-red-600">{t('create_no_credits')}</p>
        )}
      </div>
    </div>
  );
}
