import {
  Sparkles, Camera, Tag, FileText, DollarSign, MessageSquare,
  Share2, Languages, ArrowRight, Check, ChevronDown, Zap, Eye,
} from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRouter } from '@/contexts/RouterContext';

export function HomePage() {
  const { t } = useLanguage();
  const { navigate } = useRouter();
  const [faqOpen, setFaqOpen] = useState<number | null>(0);

  const steps = [
    { icon: Camera, title: t('how_step1_title'), desc: t('how_step1_desc') },
    { icon: Tag, title: t('how_step2_title'), desc: t('how_step2_desc') },
    { icon: Sparkles, title: t('how_step3_title'), desc: t('how_step3_desc') },
  ];

  const features = [
    { icon: Eye, title: t('feature_ai_title'), desc: t('feature_ai_desc') },
    { icon: DollarSign, title: t('feature_price_title'), desc: t('feature_price_desc') },
    { icon: Tag, title: t('feature_titles_title'), desc: t('feature_titles_desc') },
    { icon: FileText, title: t('feature_desc_title'), desc: t('feature_desc_desc') },
    { icon: MessageSquare, title: t('feature_buyer_title'), desc: t('feature_buyer_desc') },
    { icon: Share2, title: t('feature_platform_title'), desc: t('feature_platform_desc') },
    { icon: Languages, title: t('feature_lang_title'), desc: t('feature_lang_desc') },
    { icon: Zap, title: t('feature_ai_title'), desc: t('feature_ai_desc') },
  ];

  const faqs = [
    { q: t('faq_q1'), a: t('faq_a1') },
    { q: t('faq_q2'), a: t('faq_a2') },
    { q: t('faq_q3'), a: t('faq_a3') },
    { q: t('faq_q4'), a: t('faq_a4') },
    { q: t('faq_q5'), a: t('faq_a5') },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-slate-50 to-white">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-teal-200/30 blur-3xl" />
          <div className="absolute right-0 top-20 h-72 w-72 rounded-full bg-cyan-200/20 blur-3xl" />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-teal-200 bg-teal-50 px-4 py-1.5">
              <Sparkles className="h-4 w-4 text-teal-600" />
              <span className="text-sm font-medium text-teal-700">AI-Powered Listing Generator</span>
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl lg:text-6xl">
              {t('hero_title')}
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-600 sm:text-xl">
              {t('hero_subtitle')}
            </p>
            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <button
                onClick={() => navigate('create')}
                className="group inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-teal-600 to-cyan-600 px-8 py-4 text-base font-semibold text-white shadow-lg shadow-teal-500/25 transition-all hover:shadow-xl hover:shadow-teal-500/30 hover:-translate-y-0.5"
              >
                {t('hero_cta')}
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
              </button>
              <button
                onClick={() => {
                  document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-8 py-4 text-base font-semibold text-slate-700 transition-all hover:border-slate-400 hover:bg-slate-50"
              >
                {t('hero_secondary')}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Before/After */}
      <section className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
              {t('before_after_title')}
            </h2>
            <p className="mt-4 text-lg text-slate-600">{t('before_after_subtitle')}</p>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-2">
            {/* Before */}
            <div className="rounded-2xl border-2 border-dashed border-slate-300 bg-slate-50 p-8">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-200 px-3 py-1 text-xs font-semibold text-slate-600">
                {t('before_label')}
              </span>
              <div className="mt-4 flex h-48 items-center justify-center rounded-xl bg-slate-200">
                <Camera className="h-12 w-12 text-slate-400" />
              </div>
              <div className="mt-4 rounded-lg bg-white p-4">
                <p className="text-sm text-slate-500">{t('before_text')}</p>
              </div>
            </div>
            {/* After */}
            <div className="rounded-2xl border-2 border-teal-500 bg-teal-50/50 p-8 shadow-lg shadow-teal-500/10">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-teal-500 px-3 py-1 text-xs font-semibold text-white">
                <Sparkles className="h-3 w-3" /> {t('after_label')}
              </span>
              <div className="mt-4 flex h-48 items-center justify-center rounded-xl bg-gradient-to-br from-teal-100 to-cyan-100">
                <div className="text-center">
                  <Sparkles className="mx-auto h-10 w-10 text-teal-500" />
                  <p className="mt-2 text-sm font-medium text-teal-700">AI Generated</p>
                </div>
              </div>
              <div className="mt-4 rounded-lg bg-white p-4 shadow-sm">
                <p className="font-semibold text-slate-900">{t('after_title')}</p>
                <p className="mt-2 text-sm text-slate-600">{t('after_desc')}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="bg-slate-50 py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">{t('how_title')}</h2>
            <p className="mt-4 text-lg text-slate-600">{t('how_subtitle')}</p>
          </div>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {steps.map((step, i) => (
              <div key={i} className="relative rounded-2xl border border-slate-200 bg-white p-8 text-center transition-all hover:shadow-lg hover:-translate-y-1">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-500 to-cyan-600">
                  <step.icon className="h-8 w-8 text-white" />
                </div>
                <div className="mt-4 text-sm font-bold text-teal-600">STEP {i + 1}</div>
                <h3 className="mt-2 text-lg font-semibold text-slate-900">{step.title}</h3>
                <p className="mt-2 text-sm text-slate-600">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">{t('features_title')}</h2>
            <p className="mt-4 text-lg text-slate-600">{t('features_subtitle')}</p>
          </div>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((f, i) => (
              <div key={i} className="rounded-2xl border border-slate-200 bg-white p-6 transition-all hover:border-teal-300 hover:shadow-lg">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-teal-50">
                  <f.icon className="h-6 w-6 text-teal-600" />
                </div>
                <h3 className="mt-4 font-semibold text-slate-900">{f.title}</h3>
                <p className="mt-2 text-sm text-slate-600">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing preview */}
      <section className="bg-slate-50 py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">{t('pricing_title')}</h2>
            <p className="mt-4 text-lg text-slate-600">{t('pricing_subtitle')}</p>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {/* Free */}
            <div className="rounded-2xl border border-slate-200 bg-white p-8">
              <h3 className="text-lg font-semibold text-slate-900">{t('pricing_free')}</h3>
              <p className="mt-1 text-sm text-slate-500">{t('pricing_free_desc')}</p>
              <div className="mt-4">
                <span className="text-4xl font-bold text-slate-900">$0</span>
              </div>
              <ul className="mt-6 space-y-3">
                {[t('pricing_free_feat1'), t('pricing_free_feat2'), t('pricing_free_feat3'), t('pricing_free_feat4')].map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                    <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-teal-600" />
                    {f}
                  </li>
                ))}
              </ul>
              <button onClick={() => navigate('signup')} className="mt-8 w-full rounded-xl border border-slate-300 bg-white py-3 text-sm font-semibold text-slate-700 transition-all hover:bg-slate-50">
                {t('pricing_free_cta')}
              </button>
            </div>

            {/* Pro */}
            <div className="relative rounded-2xl border-2 border-teal-500 bg-white p-8 shadow-xl">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-teal-500 to-cyan-600 px-4 py-1 text-xs font-bold text-white">
                POPULAR
              </div>
              <h3 className="text-lg font-semibold text-slate-900">{t('pricing_pro')}</h3>
              <p className="mt-1 text-sm text-slate-500">{t('pricing_pro_desc')}</p>
              <div className="mt-4">
                <span className="text-4xl font-bold text-slate-900">$6.99</span>
                <span className="text-sm text-slate-500">{t('pricing_month')}</span>
              </div>
              <ul className="mt-6 space-y-3">
                {[t('pricing_pro_feat1'), t('pricing_pro_feat2'), t('pricing_pro_feat3'), t('pricing_pro_feat4'), t('pricing_pro_feat5'), t('pricing_pro_feat6')].map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                    <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-teal-600" />
                    {f}
                  </li>
                ))}
              </ul>
              <button onClick={() => navigate('signup')} className="mt-8 w-full rounded-xl bg-gradient-to-r from-teal-600 to-cyan-600 py-3 text-sm font-semibold text-white shadow-lg shadow-teal-500/25 transition-all hover:shadow-xl">
                {t('pricing_pro_cta')}
              </button>
            </div>

            {/* Pay once */}
            <div className="rounded-2xl border border-slate-200 bg-white p-8">
              <h3 className="text-lg font-semibold text-slate-900">{t('pricing_payonce')}</h3>
              <p className="mt-1 text-sm text-slate-500">{t('pricing_payonce_desc')}</p>
              <div className="mt-4">
                <span className="text-4xl font-bold text-slate-900">$4.99</span>
              </div>
              <ul className="mt-6 space-y-3">
                {[t('pricing_payonce_feat1'), t('pricing_payonce_feat2'), t('pricing_payonce_feat3')].map((f, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                    <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-teal-600" />
                    {f}
                  </li>
                ))}
              </ul>
              <button onClick={() => navigate('signup')} className="mt-8 w-full rounded-xl border border-slate-300 bg-white py-3 text-sm font-semibold text-slate-700 transition-all hover:bg-slate-50">
                {t('pricing_payonce_cta')}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-white py-20">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">{t('faq_title')}</h2>
          <div className="mt-10 space-y-4">
            {faqs.map((faq, i) => (
              <div key={i} className="rounded-xl border border-slate-200 bg-white overflow-hidden">
                <button
                  onClick={() => setFaqOpen(faqOpen === i ? null : i)}
                  className="flex w-full items-center justify-between px-6 py-4 text-left"
                >
                  <span className="font-semibold text-slate-900">{faq.q}</span>
                  <ChevronDown className={`h-5 w-5 flex-shrink-0 text-slate-400 transition-transform ${faqOpen === i ? 'rotate-180' : ''}`} />
                </button>
                {faqOpen === i && (
                  <div className="px-6 pb-4 text-sm text-slate-600">{faq.a}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-r from-teal-600 to-cyan-700 py-20">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">{t('cta_title')}</h2>
          <p className="mt-4 text-lg text-teal-100">{t('cta_subtitle')}</p>
          <button
            onClick={() => navigate('create')}
            className="mt-8 inline-flex items-center gap-2 rounded-xl bg-white px-8 py-4 text-base font-semibold text-teal-700 shadow-lg transition-all hover:-translate-y-0.5 hover:shadow-xl"
          >
            {t('cta_button')}
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>
      </section>
    </div>
  );
}
