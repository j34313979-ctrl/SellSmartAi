import { Check, Sparkles, CreditCard, Zap, Star } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from '@/contexts/RouterContext';

export function PricingPage() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const { navigate } = useRouter();

  const plans = [
    {
      name: t('pricing_free'),
      desc: t('pricing_free_desc'),
      price: '$0',
      period: '',
      features: [
        t('pricing_free_feat1'),
        t('pricing_free_feat2'),
        t('pricing_free_feat3'),
        t('pricing_free_feat4'),
      ],
      cta: t('pricing_free_cta'),
      highlight: false,
      icon: Star,
    },
    {
      name: t('pricing_pro'),
      desc: t('pricing_pro_desc'),
      price: '$6.99',
      period: t('pricing_month'),
      features: [
        t('pricing_pro_feat1'),
        t('pricing_pro_feat2'),
        t('pricing_pro_feat3'),
        t('pricing_pro_feat4'),
        t('pricing_pro_feat5'),
        t('pricing_pro_feat6'),
      ],
      cta: t('pricing_pro_cta'),
      highlight: true,
      icon: Sparkles,
    },
    {
      name: t('pricing_payonce'),
      desc: t('pricing_payonce_desc'),
      price: '$4.99',
      period: '',
      features: [
        t('pricing_payonce_feat1'),
        t('pricing_payonce_feat2'),
        t('pricing_payonce_feat3'),
      ],
      cta: t('pricing_payonce_cta'),
      highlight: false,
      icon: Zap,
    },
  ];

  const handleCta = () => {
    if (user) {
      navigate('create');
    } else {
      navigate('signup');
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-2xl text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-teal-200 bg-teal-50 px-4 py-1.5">
          <CreditCard className="h-4 w-4 text-teal-600" />
          <span className="text-sm font-medium text-teal-700">Pricing</span>
        </div>
        <h1 className="mt-6 text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">
          {t('pricing_title')}
        </h1>
        <p className="mt-4 text-lg text-slate-600">{t('pricing_subtitle')}</p>
      </div>

      <div className="mt-14 grid gap-6 md:grid-cols-3">
        {plans.map((plan, i) => (
          <div
            key={i}
            className={`relative rounded-2xl p-8 transition-all ${
              plan.highlight
                ? 'border-2 border-teal-500 bg-white shadow-xl shadow-teal-500/10 lg:-translate-y-4'
                : 'border border-slate-200 bg-white hover:shadow-lg'
            }`}
          >
            {plan.highlight && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-teal-500 to-cyan-600 px-4 py-1 text-xs font-bold text-white">
                POPULAR
              </div>
            )}

            <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${
              plan.highlight ? 'bg-gradient-to-br from-teal-500 to-cyan-600' : 'bg-slate-100'
            }`}>
              <plan.icon className={`h-6 w-6 ${plan.highlight ? 'text-white' : 'text-slate-600'}`} />
            </div>

            <h3 className="mt-4 text-lg font-semibold text-slate-900">{plan.name}</h3>
            <p className="mt-1 text-sm text-slate-500">{plan.desc}</p>

            <div className="mt-6">
              <span className="text-4xl font-bold text-slate-900">{plan.price}</span>
              {plan.period && <span className="text-sm text-slate-500 ml-1">{plan.period}</span>}
            </div>

            <ul className="mt-6 space-y-3">
              {plan.features.map((f, j) => (
                <li key={j} className="flex items-start gap-2 text-sm text-slate-600">
                  <Check className={`mt-0.5 h-4 w-4 flex-shrink-0 ${plan.highlight ? 'text-teal-600' : 'text-slate-400'}`} />
                  {f}
                </li>
              ))}
            </ul>

            <button
              onClick={handleCta}
              className={`mt-8 w-full rounded-xl py-3 text-sm font-semibold transition-all ${
                plan.highlight
                  ? 'bg-gradient-to-r from-teal-600 to-cyan-600 text-white shadow-lg shadow-teal-500/25 hover:shadow-xl'
                  : 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              {plan.cta}
            </button>
          </div>
        ))}
      </div>

      <p className="mt-10 text-center text-sm text-slate-400">
        Payment integration is coming soon. No payment required yet.
      </p>
    </div>
  );
}
