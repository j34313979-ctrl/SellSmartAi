import { useState, useEffect } from 'react';
import { Package, Trash2, ExternalLink, Loader2, Plus, Calendar } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from '@/contexts/RouterContext';
import { supabase } from '@/lib/supabase';
import type { Listing, ListingImage } from '@/types';

export function DashboardPage() {
  const { t, lang } = useLanguage();
  const { user } = useAuth();
  const { navigate } = useRouter();
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [imageUrls, setImageUrls] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!user) {
      navigate('signin');
      return;
    }

    const load = async () => {
      const { data, error } = await supabase
        .from('listings')
        .select('*')
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false });

      if (error || !data) {
        setLoading(false);
        return;
      }

      const listingsData = data as Listing[];
      setListings(listingsData);

      // Load first image for each listing
      const urlMap: Record<string, string> = {};
      await Promise.all(
        listingsData.map(async (listing) => {
          const { data: imgs } = await supabase
            .from('listing_images')
            .select('*')
            .eq('listing_id', listing.id)
            .order('position', { ascending: true })
            .limit(1);

          if (imgs && imgs.length > 0) {
            const img = imgs[0] as ListingImage;
            const { data: url } = supabase.storage
              .from('listing-images')
              .getPublicUrl(img.storage_path);
            if (url?.publicUrl) {
              urlMap[listing.id] = url.publicUrl;
            }
          }
        })
      );

      setImageUrls(urlMap);
      setLoading(false);
    };

    load();
  }, [user, navigate]);

  const handleDelete = async (id: string) => {
    if (!confirm(t('dashboard_delete_confirm'))) return;

    const { error } = await supabase.from('listings').delete().eq('id', id);
    if (!error) {
      setListings(listings.filter((l) => l.id !== id));
    }
  };

  const handleOpen = (listing: Listing) => {
    if (listing.generated_content) {
      navigate('results', {
        listingId: listing.id,
        content: JSON.stringify(listing.generated_content),
      });
    } else {
      navigate('create');
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString(lang === 'fr' ? 'fr-FR' : 'en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-teal-600" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">{t('dashboard_title')}</h1>
          <p className="mt-1 text-sm text-slate-500">{t('dashboard_subtitle')}</p>
        </div>
        <button
          onClick={() => navigate('create')}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-teal-600 to-cyan-600 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-teal-500/25 transition-all hover:shadow-xl"
        >
          <Plus className="h-4 w-4" />
          {t('dashboard_create')}
        </button>
      </div>

      {listings.length === 0 ? (
        <div className="mt-12 flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-300 bg-slate-50 py-20 text-center">
          <Package className="h-12 w-12 text-slate-300" />
          <h3 className="mt-4 text-lg font-semibold text-slate-900">{t('dashboard_empty')}</h3>
          <p className="mt-1 text-sm text-slate-500">{t('dashboard_empty_desc')}</p>
          <button
            onClick={() => navigate('create')}
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white transition-all hover:bg-slate-800"
          >
            <Plus className="h-4 w-4" />
            {t('dashboard_create')}
          </button>
        </div>
      ) : (
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {listings.map((listing) => (
            <div
              key={listing.id}
              className="group overflow-hidden rounded-2xl border border-slate-200 bg-white transition-all hover:border-teal-300 hover:shadow-lg"
            >
              {/* Image */}
              <div className="aspect-video bg-slate-100 overflow-hidden">
                {imageUrls[listing.id] ? (
                  <img
                    src={imageUrls[listing.id]}
                    alt=""
                    className="h-full w-full object-cover transition-transform group-hover:scale-105"
                  />
                ) : (
                  <div className="flex h-full items-center justify-center">
                    <Package className="h-8 w-8 text-slate-300" />
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-4">
                <div className="flex items-center justify-between">
                  <span
                    className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                      listing.status === 'completed'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-amber-100 text-amber-700'
                    }`}
                  >
                    {listing.status === 'completed' ? t('dashboard_completed') : t('dashboard_draft')}
                  </span>
                  <span className="flex items-center gap-1 text-xs text-slate-400">
                    <Calendar className="h-3 w-3" />
                    {formatDate(listing.updated_at)}
                  </span>
                </div>

                <h3 className="mt-2 font-semibold text-slate-900 line-clamp-1">
                  {listing.generated_content?.recommended_title ||
                    listing.item_name ||
                    'Untitled'}
                </h3>

                {listing.generated_content && (
                  <p className="mt-1 text-lg font-bold text-teal-600">
                    ${listing.generated_content.recommended_price}
                  </p>
                )}

                {/* Actions */}
                <div className="mt-4 flex gap-2">
                  <button
                    onClick={() => handleOpen(listing)}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-slate-900 px-3 py-2 text-xs font-semibold text-white transition-all hover:bg-slate-800"
                  >
                    <ExternalLink className="h-3.5 w-3.5" />
                    {t('dashboard_open')}
                  </button>
                  <button
                    onClick={() => handleDelete(listing.id)}
                    className="rounded-lg border border-slate-200 p-2 text-slate-400 transition-all hover:border-red-200 hover:bg-red-50 hover:text-red-600"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
