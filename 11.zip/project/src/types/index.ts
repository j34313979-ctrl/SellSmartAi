export interface GeneratedContent {
  product_identification: string;
  suggested_condition: string | null;
  recommended_title: string;
  alternative_titles: string[];
  full_description: string;
  short_description: string;
  recommended_price: number;
  price_range_low: number;
  price_range_high: number;
  suggested_category: string;
  keywords: string[];
  buyer_qa: { question: string; answer: string }[];
  negotiation_price: number;
  minimum_acceptable_price: number;
}

export interface Listing {
  id: string;
  user_id: string;
  item_name: string | null;
  brand: string | null;
  model: string | null;
  condition: string | null;
  location: string | null;
  language: string;
  status: string;
  generated_content: GeneratedContent | null;
  created_at: string;
  updated_at: string;
}

export interface ListingImage {
  id: string;
  listing_id: string;
  storage_path: string;
  position: number;
  created_at: string;
}

export interface Profile {
  id: string;
  free_credits_remaining: number;
  subscription_tier: string;
  subscription_status: string;
  paid_credits_remaining: number;
  monthly_credits_remaining: number;
  credits_reset_at: string | null;
  created_at: string;
}

export type Condition = 'new' | 'like_new' | 'good' | 'fair' | 'poor';
export type Language = 'en' | 'fr';
export type Platform = 'facebook' | 'kijiji' | 'ebay' | 'craigslist' | 'vinted';
