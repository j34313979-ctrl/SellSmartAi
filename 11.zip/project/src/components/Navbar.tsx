import { Sparkles, Menu, X, Globe, LogOut, LayoutDashboard, Plus, Home as HomeIcon, CreditCard } from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter, type Route } from '@/contexts/RouterContext';
import type { Language } from '@/types';

export function Navbar() {
  const { t, lang, setLang } = useLanguage();
  const { user, profile, signOut } = useAuth();
  const { navigate, route } = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);

  const totalCredits =
    (profile?.free_credits_remaining || 0) +
    (profile?.paid_credits_remaining || 0) +
    (profile?.monthly_credits_remaining || 0);

  const navLink = (label: string, target: Route, active: boolean) => (
    <button
      onClick={() => {
        navigate(target);
        setMobileOpen(false);
      }}
      className={`text-sm font-medium transition-colors ${
        active ? 'text-teal-600' : 'text-slate-600 hover:text-slate-900'
      }`}
    >
      {label}
    </button>
  );

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/80 backdrop-blur-lg">
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <button onClick={() => navigate('home')} className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-cyan-600">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <span className="text-lg font-bold tracking-tight text-slate-900">
            SellSmart<span className="text-teal-600"> AI</span>
          </span>
        </button>

        {/* Desktop nav */}
        <div className="hidden items-center gap-8 md:flex">
          {navLink(t('nav_home'), 'home', route === 'home')}
          {navLink(t('nav_create'), 'create', route === 'create')}
          {navLink(t('nav_pricing'), 'pricing', route === 'pricing')}
          {user && navLink(t('nav_dashboard'), 'dashboard', route === 'dashboard')}
        </div>

        {/* Right side */}
        <div className="hidden items-center gap-4 md:flex">
          {/* Language switcher */}
          <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
            <Globe className="ml-1.5 h-4 w-4 text-slate-400" />
            {(['en', 'fr'] as Language[]).map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                className={`rounded-md px-2.5 py-1 text-xs font-semibold uppercase transition-all ${
                  lang === l ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                {l}
              </button>
            ))}
          </div>

          {user ? (
            <>
              <div className="flex items-center gap-1.5 rounded-lg bg-teal-50 px-3 py-1.5">
                <CreditCard className="h-4 w-4 text-teal-600" />
                <span className="text-sm font-semibold text-teal-700">
                  {totalCredits} {t('nav_credits')}
                </span>
              </div>
              <button
                onClick={() => signOut()}
                className="flex items-center gap-1.5 text-sm font-medium text-slate-600 hover:text-slate-900"
              >
                <LogOut className="h-4 w-4" />
                {t('nav_signout')}
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => navigate('signin')}
                className="text-sm font-medium text-slate-600 hover:text-slate-900"
              >
                {t('nav_signin')}
              </button>
              <button
                onClick={() => navigate('signup')}
                className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white transition-all hover:bg-slate-800"
              >
                {t('nav_signup')}
              </button>
            </>
          )}
        </div>

        {/* Mobile menu button */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 md:hidden"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="border-t border-slate-200 bg-white px-4 py-4 md:hidden">
          <div className="flex flex-col gap-4">
            <button onClick={() => { navigate('home'); setMobileOpen(false); }} className="flex items-center gap-2 text-sm font-medium text-slate-700">
              <HomeIcon className="h-4 w-4" /> {t('nav_home')}
            </button>
            <button onClick={() => { navigate('create'); setMobileOpen(false); }} className="flex items-center gap-2 text-sm font-medium text-slate-700">
              <Plus className="h-4 w-4" /> {t('nav_create')}
            </button>
            <button onClick={() => { navigate('pricing'); setMobileOpen(false); }} className="flex items-center gap-2 text-sm font-medium text-slate-700">
              <CreditCard className="h-4 w-4" /> {t('nav_pricing')}
            </button>
            {user && (
              <button onClick={() => { navigate('dashboard'); setMobileOpen(false); }} className="flex items-center gap-2 text-sm font-medium text-slate-700">
                <LayoutDashboard className="h-4 w-4" /> {t('nav_dashboard')}
              </button>
            )}

            {/* Language switcher */}
            <div className="flex items-center gap-2 pt-2">
              <Globe className="h-4 w-4 text-slate-400" />
              {(['en', 'fr'] as Language[]).map((l) => (
                <button
                  key={l}
                  onClick={() => setLang(l)}
                  className={`rounded-md px-3 py-1 text-xs font-semibold uppercase ${
                    lang === l ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>

            {user ? (
              <>
                <div className="rounded-lg bg-teal-50 px-3 py-2 text-sm font-semibold text-teal-700">
                  {totalCredits} {t('nav_credits')}
                </div>
                <button onClick={() => { signOut(); setMobileOpen(false); }} className="flex items-center gap-2 text-sm font-medium text-slate-700">
                  <LogOut className="h-4 w-4" /> {t('nav_signout')}
                </button>
              </>
            ) : (
              <div className="flex gap-2 pt-2">
                <button onClick={() => { navigate('signin'); setMobileOpen(false); }} className="flex-1 rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700">
                  {t('nav_signin')}
                </button>
                <button onClick={() => { navigate('signup'); setMobileOpen(false); }} className="flex-1 rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white">
                  {t('nav_signup')}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
