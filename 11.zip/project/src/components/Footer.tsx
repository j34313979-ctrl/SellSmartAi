import { Sparkles } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRouter } from '@/contexts/RouterContext';

export function Footer() {
  const { t } = useLanguage();
  const { navigate } = useRouter();

  return (
    <footer className="border-t border-slate-200 bg-slate-50">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          <div className="col-span-2 md:col-span-1">
            <button onClick={() => navigate('home')} className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-teal-500 to-cyan-600">
                <Sparkles className="h-4 w-4 text-white" />
              </div>
              <span className="text-base font-bold text-slate-900">
                SellSmart<span className="text-teal-600"> AI</span>
              </span>
            </button>
            <p className="mt-3 text-sm text-slate-500">{t('footer_tagline')}</p>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-900">{t('footer_product')}</h4>
            <ul className="mt-3 space-y-2">
              <li>
                <button onClick={() => navigate('create')} className="text-sm text-slate-500 hover:text-slate-900">
                  {t('nav_create')}
                </button>
              </li>
              <li>
                <button onClick={() => navigate('pricing')} className="text-sm text-slate-500 hover:text-slate-900">
                  {t('nav_pricing')}
                </button>
              </li>
              {(
                <li>
                  <button onClick={() => navigate('dashboard')} className="text-sm text-slate-500 hover:text-slate-900">
                    {t('nav_dashboard')}
                  </button>
                </li>
              )}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-900">{t('footer_company')}</h4>
            <ul className="mt-3 space-y-2">
              <li><span className="cursor-default text-sm text-slate-500">About</span></li>
              <li><span className="cursor-default text-sm text-slate-500">Blog</span></li>
              <li><span className="cursor-default text-sm text-slate-500">Contact</span></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-900">{t('footer_legal')}</h4>
            <ul className="mt-3 space-y-2">
              <li><span className="cursor-default text-sm text-slate-500">Privacy</span></li>
              <li><span className="cursor-default text-sm text-slate-500">Terms</span></li>
              <li><span className="cursor-default text-sm text-slate-500">Cookies</span></li>
            </ul>
          </div>
        </div>

        <div className="mt-8 border-t border-slate-200 pt-6 text-center">
          <p className="text-sm text-slate-400">
            &copy; {new Date().getFullYear()} SellSmart AI. {t('footer_rights')}
          </p>
        </div>
      </div>
    </footer>
  );
}
