import type { GeneratedContent, Platform } from '@/types';

export function formatForPlatform(content: GeneratedContent, platform: Platform): string {
  const title = content.recommended_title;
  const price = content.recommended_price;
  const desc = content.full_description;
  const category = content.suggested_category;
  const condition = content.suggested_condition || '';

  switch (platform) {
    case 'facebook':
      return `${title}\n\n${desc}\n\nPrice: $${price}\nCondition: ${condition}\nCategory: ${category}`;

    case 'kijiji':
      return `Title: ${title}\n\nPrice: $${price}\nCategory: ${category}\nCondition: ${condition}\n\nDescription:\n${desc}`;

    case 'ebay':
      return `Title: ${title}\nSubtitle: ${content.short_description}\nCondition: ${condition}\nCategory: ${category}\nStarting Price: $${price}\nBuy It Now: $${content.price_range_high}\n\nDescription:\n${desc}`;

    case 'craigslist':
      return `${title} - $${price}\n\n${desc}\n\nCondition: ${condition}\nLocation: See listing`;

    case 'vinted':
      return `${title}\n\n${content.short_description}\n\nBrand: ${content.suggested_category}\nCondition: ${condition}\nPrice: $${price}\n\n${desc}`;

    default:
      return `${title}\n\n${desc}\n\n$${price}`;
  }
}
