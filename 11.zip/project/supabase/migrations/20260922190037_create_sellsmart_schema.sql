/*
# SellSmart AI — Initial Schema

## Overview
Creates the full database structure for the SellSmart AI application:
user profiles (with free credits and subscription info), listings (with all
AI-generated content stored as JSONB), and listing images (uploaded photos).
Also creates a private storage bucket for listing photos with row-level
security so each user can only access their own images.

## 1. New Tables

### profiles
- `id` (uuid, primary key, references auth.users) — one row per user
- `free_credits_remaining` (int, default 3) — free AI generations left
- `subscription_tier` (text, default 'free') — 'free' or 'pro'
- `subscription_status` (text, default 'inactive') — 'active' or 'inactive'
- `paid_credits_remaining` (int, default 0) — credits from pay-once packs
- `monthly_credits_remaining` (int, default 0) — Pro monthly credits
- `credits_reset_at` (timestamptz) — when monthly credits refresh
- `created_at` (timestamptz, default now())

### listings
- `id` (uuid, primary key)
- `user_id` (uuid, not null, defaults to auth.uid, references auth.users)
- `item_name` (text, nullable) — what the user said they're selling
- `brand` (text, nullable)
- `model` (text, nullable)
- `condition` (text, nullable) — new/like_new/good/fair/poor
- `location` (text, nullable)
- `language` (text, not null, default 'en') — 'en' or 'fr'
- `status` (text, not null, default 'draft') — 'draft' or 'completed'
- `generated_content` (jsonb, nullable) — all AI output
- `created_at` (timestamptz, default now())
- `updated_at` (timestamptz, default now())

### listing_images
- `id` (uuid, primary key)
- `listing_id` (uuid, not null, references listings ON DELETE CASCADE)
- `storage_path` (text, not null) — path in the listing-images bucket
- `position` (int, default 0) — image order
- `created_at` (timestamptz, default now())

## 2. Security (RLS)
- profiles: each authenticated user can read/update only their own profile row
- listings: each authenticated user can CRUD only their own listings
- listing_images: access scoped through the parent listing's owner
- Storage bucket 'listing-images': users can read/write/delete only their own folder

## 3. Important Notes
- user_id defaults to auth.uid() so client inserts that omit user_id succeed
- listing_images ownership is checked via EXISTS subquery on listings
- updated_at auto-refreshes via trigger on listings table
*/

-- ============ PROFILES ============
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  free_credits_remaining int NOT NULL DEFAULT 3,
  subscription_tier text NOT NULL DEFAULT 'free',
  subscription_status text NOT NULL DEFAULT 'inactive',
  paid_credits_remaining int NOT NULL DEFAULT 0,
  monthly_credits_remaining int NOT NULL DEFAULT 0,
  credits_reset_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ============ LISTINGS ============
CREATE TABLE IF NOT EXISTS listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  item_name text,
  brand text,
  model text,
  condition text,
  location text,
  language text NOT NULL DEFAULT 'en',
  status text NOT NULL DEFAULT 'draft',
  generated_content jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE listings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_listings" ON listings;
CREATE POLICY "select_own_listings" ON listings FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_listings" ON listings;
CREATE POLICY "insert_own_listings" ON listings FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_listings" ON listings;
CREATE POLICY "update_own_listings" ON listings FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_listings" ON listings;
CREATE POLICY "delete_own_listings" ON listings FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS listings_updated_at ON listings;
CREATE TRIGGER listings_updated_at BEFORE UPDATE ON listings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============ LISTING_IMAGES ============
CREATE TABLE IF NOT EXISTS listing_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  storage_path text NOT NULL,
  position int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE listing_images ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_listing_images" ON listing_images;
CREATE POLICY "select_own_listing_images" ON listing_images FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM listings WHERE listings.id = listing_images.listing_id AND listings.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_listing_images" ON listing_images;
CREATE POLICY "insert_own_listing_images" ON listing_images FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM listings WHERE listings.id = listing_images.listing_id AND listings.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "delete_own_listing_images" ON listing_images;
CREATE POLICY "delete_own_listing_images" ON listing_images FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM listings WHERE listings.id = listing_images.listing_id AND listings.user_id = auth.uid())
  );

-- ============ STORAGE BUCKET ============
INSERT INTO storage.buckets (id, name, public)
VALUES ('listing-images', 'listing-images', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: users can only access their own folder (user_id/...)
DROP POLICY IF EXISTS "Users can upload own listing images" ON storage.objects;
CREATE POLICY "Users can upload own listing images" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'listing-images' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "Users can read own listing images" ON storage.objects;
CREATE POLICY "Users can read own listing images" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'listing-images' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "Users can update own listing images" ON storage.objects;
CREATE POLICY "Users can update own listing images" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'listing-images' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "Users can delete own listing images" ON storage.objects;
CREATE POLICY "Users can delete own listing images" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'listing-images' AND (storage.foldername(name))[1] = auth.uid()::text);

-- ============ AUTO-CREATE PROFILE ON SIGNUP ============
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO profiles (id) VALUES (NEW.id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();