import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface GenerateRequest {
  listingId: string;
  images: string[]; // storage paths in listing-images bucket
  itemName?: string;
  brand?: string;
  model?: string;
  condition?: string;
  location?: string;
  language: string; // 'en' or 'fr'
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body: GenerateRequest = await req.json();
    const {
      listingId,
      images,
      itemName,
      brand,
      model,
      condition,
      location,
      language,
    } = body;

    if (!listingId || !images || images.length === 0) {
      return new Response(
        JSON.stringify({ error: "Missing listingId or images" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get the user from the JWT
    const authHeader = req.headers.get("Authorization")!;
    const userClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userError } = await userClient.auth.getUser();
    if (userError || !userData.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userId = userData.user.id;

    // Check credits
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("free_credits_remaining, paid_credits_remaining, monthly_credits_remaining, subscription_tier, subscription_status")
      .eq("id", userId)
      .single();

    if (profileError || !profile) {
      return new Response(JSON.stringify({ error: "Profile not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const totalCredits =
      (profile.free_credits_remaining || 0) +
      (profile.paid_credits_remaining || 0) +
      (profile.monthly_credits_remaining || 0);

    if (totalCredits <= 0) {
      return new Response(JSON.stringify({ error: "No credits remaining" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Download images from storage and convert to base64
    const imagePromises = images.map(async (path: string) => {
      const { data, error } = await supabase.storage
        .from("listing-images")
        .download(path);
      if (error || !data) return null;
      const buf = await data.arrayBuffer();
      const bytes = new Uint8Array(buf);
      let binary = "";
      for (let i = 0; i < bytes.length; i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      const contentType = data.type || "image/jpeg";
      return `data:${contentType};base64,${btoa(binary)}`;
    });

    const imageUrls = (await Promise.all(imagePromises)).filter(Boolean) as string[];

    if (imageUrls.length === 0) {
      return new Response(JSON.stringify({ error: "Could not load images" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Call OpenAI Vision API
    const openaiKey = Deno.env.get("OPENAI_API_KEY");
    if (!openaiKey) {
      return new Response(
        JSON.stringify({ error: "OpenAI API key not configured. Add OPENAI_API_KEY to edge function secrets." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const langName = language === "fr" ? "French" : "English";
    const conditionText = condition ? `Condition stated by seller: ${condition}.` : "Condition not specified by seller.";
    const itemInfo = [
      itemName ? `Seller says it might be: ${itemName}` : null,
      brand ? `Brand (if known): ${brand}` : null,
      model ? `Model (if known): ${model}` : null,
      location ? `Seller location: ${location}` : null,
    ].filter(Boolean).join("\n");

    const prompt = `You are an expert at creating optimized online marketplace listings. Analyze the provided photos and create a complete selling listing.

${itemInfo}
${conditionText}
The listing should be written in ${langName}.

Based on the photos and information provided, generate a JSON object with these fields:
{
  "product_identification": "What you think the item is. If you cannot confidently identify it, say so and suggest the user verify.",
  "suggested_condition": "Your assessment of the condition based on the photos, or null if unclear",
  "recommended_title": "An optimized, catchy marketplace title (max 80 chars)",
  "alternative_titles": ["5 alternative titles, each max 80 chars"],
  "full_description": "A complete, natural, human-sounding selling description with paragraphs. Do not make unrealistic claims about condition. If unsure about something, say the buyer should verify.",
  "short_description": "A 1-2 sentence summary",
  "recommended_price": <number>,
  "price_range_low": <number>,
  "price_range_high": <number>,
  "suggested_category": "A marketplace category",
  "keywords": ["relevant", "search", "keywords"],
  "buyer_qa": [
    {"question": "Is this still available?", "answer": "..."},
    {"question": "What's your lowest price?", "answer": "..."},
    {"question": "Can you deliver?", "answer": "..."},
    {"question": "Any damage?", "answer": "..."},
    {"question": "Why are you selling it?", "answer": "..."}
  ],
  "negotiation_price": <number, the price to accept during negotiation>,
  "minimum_acceptable_price": <number, the absolute lowest price to accept>
}

All text fields must be in ${langName}. Be honest about condition. Do not exaggerate. If you cannot identify the product confidently, clearly say so. Respond ONLY with the JSON object, no markdown, no explanation.`;

    const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: prompt },
              ...imageUrls.map((url) => ({
                type: "image_url",
                image_url: { url, detail: "high" },
              })),
            ],
          },
        ],
        max_tokens: 2000,
        response_format: { type: "json_object" },
      }),
    });

    if (!openaiResponse.ok) {
      const errText = await openaiResponse.text();
      return new Response(
        JSON.stringify({ error: `AI service error: ${openaiResponse.status}`, details: errText }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const openaiData = await openaiResponse.json();
    const content = openaiData.choices?.[0]?.message?.content;

    if (!content) {
      return new Response(JSON.stringify({ error: "AI returned no content" }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let generatedContent;
    try {
      generatedContent = JSON.parse(content);
    } catch {
      return new Response(JSON.stringify({ error: "AI returned invalid JSON" }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Save generated content to the listing
    const { error: updateError } = await supabase
      .from("listings")
      .update({ generated_content: generatedContent, status: "completed" })
      .eq("id", listingId);

    if (updateError) {
      console.error("Failed to update listing:", updateError);
    }

    // Decrement credits: free first, then paid, then monthly
    let updateData: Record<string, number> = {};
    if (profile.free_credits_remaining > 0) {
      updateData.free_credits_remaining = profile.free_credits_remaining - 1;
    } else if (profile.paid_credits_remaining > 0) {
      updateData.paid_credits_remaining = profile.paid_credits_remaining - 1;
    } else if (profile.monthly_credits_remaining > 0) {
      updateData.monthly_credits_remaining = profile.monthly_credits_remaining - 1;
    }

    await supabase.from("profiles").update(updateData).eq("id", userId);

    return new Response(JSON.stringify({ content: generatedContent }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
